package io.github.adytech99.healthindicators.fabric.commands;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import io.github.adytech99.healthindicators.HealthIndicatorsCommon;
import io.github.adytech99.healthindicators.RenderTracker;
import io.github.adytech99.healthindicators.config.ModConfig;
import io.github.adytech99.healthindicators.enums.HealthDisplayTypeEnum;
import io.github.adytech99.healthindicators.util.ConfigUtils;
import io.github.adytech99.healthindicators.util.Util;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_7157;
import java.util.Objects;

public class ModCommands {
    @Environment(EnvType.CLIENT)
    public static void registerCommands(){
        ClientCommandRegistrationCallback.EVENT.register(ModCommands::configCommands);
        ClientCommandRegistrationCallback.EVENT.register(ModCommands::openModMenuCommand);
    }


    private static void configCommands(CommandDispatcher<FabricClientCommandSource> fabricClientCommandSourceCommandDispatcher, class_7157 commandRegistryAccess) {
        fabricClientCommandSourceCommandDispatcher.register(ClientCommandManager.literal("healthindicators")
            .then(ClientCommandManager.literal("offset")
                .then(ClientCommandManager.argument("offset", DoubleArgumentType.doubleArg())
                    .executes(context -> {
                        ModConfig.HANDLER.instance().display_offset = Math.clamp(
                                DoubleArgumentType.getDouble(context, "offset"),
                                -5.0, 5.0);
                        ModConfig.HANDLER.save();
                        ConfigUtils.sendMessage(context.getSource().getPlayer(), class_2561.method_43470("Set heart offset to " + Util.truncate(ModConfig.getDisplayOffset(),2)));
                        return 1;
                    })))

            .then(ClientCommandManager.literal("indicator-type")
                .then(ClientCommandManager.argument("indicator_type", StringArgumentType.string())
                    .suggests((context, builder) -> {
                        builder.suggest("heart");
                        builder.suggest("number");
                        return builder.buildFuture();
                    })
                        .executes(context -> {
                            HealthDisplayTypeEnum displayTypeEnum;
                            if (StringArgumentType.getString(context, "indicator_type").equals("heart")) {
                                displayTypeEnum = HealthDisplayTypeEnum.HEARTS;
                            } else if (StringArgumentType.getString(context, "indicator_type").equals("number")) {
                                displayTypeEnum = HealthDisplayTypeEnum.NUMBER;
                            } else {
                                ConfigUtils.sendMessage(context.getSource().getPlayer(), class_2561.method_43470("Unknown argument, please try again."));
                                return 1;
                            }

                            ModConfig.HANDLER.instance().indicator_type = displayTypeEnum;
                            ModConfig.HANDLER.save();
                            ConfigUtils.sendMessage(context.getSource().getPlayer(), class_2561.method_43470("Set display type to " + ModConfig.HANDLER.instance().indicator_type));
                            return 1;
                        })))


            .then(ClientCommandManager.literal("monitor")
                .then(ClientCommandManager.argument("entity_name", StringArgumentType.string())
                        .suggests((context, builder) -> {
                            for(class_1297 entity : context.getSource().getWorld().method_18112()){
                                if(entity.method_16914()) builder.suggest(Objects.requireNonNull(entity.method_5797()).getString());
                                if(entity.method_31747()) builder.suggest(Objects.requireNonNull(entity.method_5476()).getString());
                            }
                            return builder.buildFuture();
                        })
                        .executes(context -> {
                            if(Util.getEntityFromName(context.getSource().getWorld(), StringArgumentType.getString(context, "entity_name")) != null) {
                                ConfigUtils.sendMessage(context.getSource().getPlayer(), (class_2561.method_43470("Now monitoring " + StringArgumentType.getString(context, "entity_name"))));
                                RenderTracker.setTrackedEntity((class_1309) Util.getEntityFromName(context.getSource().getWorld(), StringArgumentType.getString(context, "entity_name")));
                            }
                            else ConfigUtils.sendMessage(context.getSource().getPlayer(), (class_2561.method_43470("There is no entity named " + StringArgumentType.getString(context, "entity_name") + " in the world. It may have died or gone out of render distance.")));
                            return 0;
                        })))

            .then(ClientCommandManager.literal("stop-monitoring")
                .executes(context -> {
                    RenderTracker.setTrackedEntity(null);
                    ConfigUtils.sendMessage(context.getSource().getPlayer(), (class_2561.method_43470("Stopped monitoring ")));
                    return 0;
                }))
        );
    }

    private static void IndicatorTypeCommand(CommandDispatcher<FabricClientCommandSource> fabricClientCommandSourceCommandDispatcher, class_7157 commandRegistryAccess) {
        fabricClientCommandSourceCommandDispatcher.register(ClientCommandManager.literal("healthindicators")
                .then(ClientCommandManager.argument("operation", StringArgumentType.string())
                        .suggests((context, builder) -> {
                            builder.suggest("indicator_type");
                            return builder.buildFuture();
                        })
                            .then(ClientCommandManager.argument("indicator_type", StringArgumentType.string())
                                .suggests((context, builder) -> {
                                    builder.suggest("heart");
                                    builder.suggest("number");
                                    return builder.buildFuture();
                                })
                                .executes(context -> {
                                    HealthDisplayTypeEnum displayTypeEnum;
                                    if(StringArgumentType.getString(context, "indicator_type").equals("heart")){
                                        displayTypeEnum = HealthDisplayTypeEnum.HEARTS;
                                    } else if (StringArgumentType.getString(context, "indicator_type").equals("number")) {
                                        displayTypeEnum = HealthDisplayTypeEnum.NUMBER;
                                    }
                                    else {
                                        ConfigUtils.sendMessage(context.getSource().getPlayer(), class_2561.method_43470("Unknown argument, please try again."));
                                        return 1;
                                    }

                                    ModConfig.HANDLER.instance().indicator_type = displayTypeEnum;
                                    ModConfig.HANDLER.save();
                                    ConfigUtils.sendMessage(context.getSource().getPlayer(), class_2561.method_43470("Set display type to " + ModConfig.HANDLER.instance().indicator_type));
                                    return 1;
                                }))));
    }

    private static void openModMenuCommand(CommandDispatcher<FabricClientCommandSource> fabricClientCommandSourceCommandDispatcher, class_7157 commandRegistryAccess) {
        fabricClientCommandSourceCommandDispatcher.register(ClientCommandManager.literal("healthindicators")
            .executes(context -> {
                HealthIndicatorsCommon.openConfig();
                return 1;
        }));
    }
}
