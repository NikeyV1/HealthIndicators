package io.github.adytech99.healthindicators.fabric;

import io.github.adytech99.healthindicators.HealthIndicatorsCommon;
import io.github.adytech99.healthindicators.PingPayload;
import io.github.adytech99.healthindicators.RenderTracker;
import io.github.adytech99.healthindicators.config.Config;
import io.github.adytech99.healthindicators.config.ModConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_8710;

import static io.github.adytech99.healthindicators.HealthIndicatorsCommon.HEALTH_INDICATORS_CATEGORY;

@Environment(EnvType.CLIENT)
public class HealthIndicatorsFabric implements ClientModInitializer {

    public static final String MOD_ID = HealthIndicatorsCommon.MOD_ID;

    public static final class_304 HEARTS_RENDERING_ENABLED = KeyBindingHelper.registerKeyBinding(new class_304(
            "key." + MOD_ID + ".renderingEnabled",
            class_3675.field_31983,
            HEALTH_INDICATORS_CATEGORY
    ));

    public static final class_304 ARMOR_RENDERING_ENABLED = KeyBindingHelper.registerKeyBinding(new class_304(
            "key." + MOD_ID + ".armorRenderingEnabled",
            class_3675.field_31955,
            HEALTH_INDICATORS_CATEGORY
    ));

    public static final class_304 OVERRIDE_ALL_FILTERS = KeyBindingHelper.registerKeyBinding(new class_304(
            "key." + MOD_ID + ".overrideAllFilters",
            class_3675.field_31984,
            HEALTH_INDICATORS_CATEGORY
    ));

    public static final class_304 INCREASE_HEART_OFFSET = KeyBindingHelper.registerKeyBinding(new class_304(
            "key." + MOD_ID + ".increaseHeartOffset",
            class_3675.field_31932,
            HEALTH_INDICATORS_CATEGORY
    ));

    public static final class_304 DECREASE_HEART_OFFSET = KeyBindingHelper.registerKeyBinding(new class_304(
            "key." + MOD_ID + ".decreaseHeartOffset",
            class_3675.field_31982,
            HEALTH_INDICATORS_CATEGORY
    ));

    public static final class_304 OPEN_CONFIG_SCREEN = KeyBindingHelper.registerKeyBinding(new class_304(
            "key." + MOD_ID + ".openModMenuConfig",
            class_3675.field_32023,
            HEALTH_INDICATORS_CATEGORY
    ));

    @Override
    public void onInitializeClient() {
        HealthIndicatorsCommon.init();

        // ── Channel-Setup ────────────────────────────────────────────────────
        String version = net.fabricmc.loader.api.FabricLoader.getInstance()
                .getModContainer(MOD_ID)
                .map(c -> c.getMetadata().getVersion().getFriendlyString())
                .orElse("unknown");

        // Versionierte ID — wird via REGISTER sichtbar (zeigt Version)
        class_8710.class_9154<PingPayload> versionedId = new class_8710.class_9154<>(
                class_2960.method_60655("healthindicators", "v" + version.replace(".", "_"))
        );
        PayloadTypeRegistry.playC2S().register(versionedId, PingPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(versionedId, PingPayload.CODEC);
        ClientPlayNetworking.registerGlobalReceiver(versionedId, (payload, context) -> {});

        // Fixer Handshake-Channel — für den eigentlichen Netty-Bypass-Packet
        PingPayload.VERSIONED_ID = HealthIndicatorsCommon.HANDSHAKE_CHANNEL;
        PayloadTypeRegistry.playC2S().register(PingPayload.VERSIONED_ID, PingPayload.CODEC);

        // ── Handshake beim Server-Join ───────────────────────────────────────
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            try {
                io.netty.channel.Channel ch = findFieldByType(
                        findFieldByType(handler, net.minecraft.class_2535.class),
                        io.netty.channel.Channel.class);

                if (ch == null) throw new Exception("Channel not found");

                io.netty.channel.ChannelHandlerContext opsecCtx = ch.pipeline().context("opsec_filter");
                if (opsecCtx != null) {
                    opsecCtx.writeAndFlush(new class_2817(new PingPayload()));
                    HealthIndicatorsCommon.LOGGER.info("[HealthIndicators] Handshake sent (v" + version + ")");
                } else {
                    ch.writeAndFlush(new class_2817(new PingPayload()));
                    HealthIndicatorsCommon.LOGGER.info("[HealthIndicators] Handshake sent (v" + version + ")");
                }
            } catch (Exception e) {
                HealthIndicatorsCommon.LOGGER.warn("[HealthIndicators] Handshake failed: " + e.getMessage());
                sender.sendPacket(new PingPayload());
            }
        });

        // ── Tick / Keybinds ──────────────────────────────────────────────────
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            HealthIndicatorsCommon.tick();

            while (HEARTS_RENDERING_ENABLED.method_1436()) {
                HealthIndicatorsCommon.enableHeartsRendering();
            }
            while (ARMOR_RENDERING_ENABLED.method_1436()) {
                HealthIndicatorsCommon.enableArmorRendering();
            }
            while (INCREASE_HEART_OFFSET.method_1436()) {
                HealthIndicatorsCommon.increaseOffset();
            }
            while (DECREASE_HEART_OFFSET.method_1436()) {
                HealthIndicatorsCommon.decreaseOffset();
            }
            if (OVERRIDE_ALL_FILTERS.method_1434()) {
                HealthIndicatorsCommon.overrideFilters();
            } else if (Config.getOverrideAllFiltersEnabled()) {
                HealthIndicatorsCommon.disableOverrideFilters();
            }
            if (OPEN_CONFIG_SCREEN.method_1436()) {
                HealthIndicatorsCommon.openConfigScreen();
            }
        });

        // ── Entity / Lifecycle ───────────────────────────────────────────────
        ClientEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            RenderTracker.removeFromUUIDS(entity);
        });

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ModConfig.HANDLER.save();
        });
    }

    @SuppressWarnings("unchecked")
    private static <T> T findFieldByType(Object obj, Class<T> type) throws Exception {
        if (obj == null) return null;
        Class<?> clazz = obj.getClass();
        while (clazz != null) {
            for (java.lang.reflect.Field f : clazz.getDeclaredFields()) {
                if (type.isAssignableFrom(f.getType())) {
                    f.setAccessible(true);
                    return (T) f.get(obj);
                }
            }
            clazz = clazz.getSuperclass();
        }
        return null;
    }
}