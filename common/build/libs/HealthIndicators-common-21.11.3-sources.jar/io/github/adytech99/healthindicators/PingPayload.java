package io.github.adytech99.healthindicators;

import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record PingPayload() implements class_8710 {

    // Wird zur Laufzeit mit der versionierten ID überschrieben
    public static class_8710.class_9154<PingPayload> VERSIONED_ID;

    public static final class_9139<class_2540, PingPayload> CODEC =
            class_9139.method_56431(new PingPayload());

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return VERSIONED_ID;
    }
}