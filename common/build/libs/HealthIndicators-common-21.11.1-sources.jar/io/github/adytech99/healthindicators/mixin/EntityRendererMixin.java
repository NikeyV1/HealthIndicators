package io.github.adytech99.healthindicators.mixin;
import io.github.adytech99.healthindicators.config.Config;
import io.github.adytech99.healthindicators.config.ModConfig;
import io.github.adytech99.healthindicators.enums.ArmorTypeEnum;
import io.github.adytech99.healthindicators.enums.HealthDisplayTypeEnum;
import io.github.adytech99.healthindicators.enums.HeartTypeEnum;
import io.github.adytech99.healthindicators.RenderTracker;
import io.github.adytech99.healthindicators.util.HeartJumpData;
import io.github.adytech99.healthindicators.util.RenderUtils;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_11785;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_3883;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import static io.github.adytech99.healthindicators.enums.HeartTypeEnum.addHardcoreIcon;
import static io.github.adytech99.healthindicators.enums.HeartTypeEnum.addStatusIcon;


@Mixin(class_922.class)
public abstract class EntityRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>>
        extends class_897<T, S>
        implements class_3883<S, M> {
            
    @Unique private final class_310 client = class_310.method_1551();
    @Unique private static final class_2960 ICONS_TEXTURE = class_2960.method_60655("minecraft", "textures/gui/icons.png");
    @Unique private static final java.util.WeakHashMap<class_10042, class_1309> ENTITY_MAP = new java.util.WeakHashMap<>();
    
    protected EntityRendererMixin(class_5617.class_5618 ctx) {
        super(ctx);
    }
    @Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V", at = @At("TAIL"), remap = false)
    public void updateRenderState(T livingEntity, S livingEntityRenderState, float f, CallbackInfo ci){
        // Store the entity in a WeakHashMap keyed by the render state
        // This prevents the health sharing bug where entities of the same type show the same health
        // Using WeakHashMap ensures render states are garbage collected when no longer needed
        ENTITY_MAP.put(livingEntityRenderState, livingEntity);
    }
    @Inject(method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V", at = @At("TAIL"), remap = false)
    public void render(S livingEntityRenderState, class_4587 matrixStack, class_11659 orderedRenderCommandQueue, class_12075 cameraRenderState, CallbackInfo ci) {
        // Retrieve the entity from the map
        class_1309 livingEntity = ENTITY_MAP.get(livingEntityRenderState);
        
        if (livingEntity != null && (RenderTracker.isInUUIDS(livingEntity) || (Config.getOverrideAllFiltersEnabled() && !RenderTracker.isInvalid(livingEntity)))) {
            if(Config.getHeartsRenderingEnabled() || Config.getOverrideAllFiltersEnabled()) {
                if (ModConfig.HANDLER.instance().indicator_type == HealthDisplayTypeEnum.HEARTS)
                    renderHearts(livingEntity, livingEntityRenderState.field_53446, 0, matrixStack, orderedRenderCommandQueue);
                else if (ModConfig.HANDLER.instance().indicator_type == HealthDisplayTypeEnum.NUMBER)
                    renderNumber(livingEntity, livingEntityRenderState.field_53446, 0, matrixStack, orderedRenderCommandQueue);
                else if (ModConfig.HANDLER.instance().indicator_type == HealthDisplayTypeEnum.DYNAMIC) {
                    if (livingEntity.method_6063() > ModConfig.HANDLER.instance().dynamic_health_threshold)
                        renderNumber(livingEntity, livingEntityRenderState.field_53446, 0, matrixStack, orderedRenderCommandQueue);
                    else renderHearts(livingEntity, livingEntityRenderState.field_53446, 0, matrixStack, orderedRenderCommandQueue);
                }
            }
            if(Config.getArmorRenderingEnabled() || Config.getOverrideAllFiltersEnabled()) renderArmorPoints(livingEntity, livingEntityRenderState.field_53446, 0, matrixStack, orderedRenderCommandQueue);
        }
    }
    @SuppressWarnings("unchecked")
    @Unique private void renderHearts(class_1309 livingEntity, float yaw, float tickDelta, class_4587 matrixStack, class_11659 orderedRenderCommandQueue){
        double d = this.field_4676.method_23168(livingEntity);
        final T entAsT = (T) livingEntity; // retained for hasLabel calls
        int healthRed = class_3532.method_15386(livingEntity.method_6032());
        int maxHealth = class_3532.method_15386(livingEntity.method_6063());
        int healthYellow = class_3532.method_15386(livingEntity.method_6067());
        if(ModConfig.HANDLER.instance().percentage_based_health) {
            healthRed = class_3532.method_15386(((float) healthRed /maxHealth) * ModConfig.HANDLER.instance().max_health);
            maxHealth = class_3532.method_15386(ModConfig.HANDLER.instance().max_health);
            healthYellow = class_3532.method_15386(livingEntity.method_6067());
        }
        int heartsRed = class_3532.method_15386(healthRed / 2.0F);
        boolean lastRedHalf = (healthRed & 1) == 1;
        int heartsNormal = class_3532.method_15386(maxHealth / 2.0F);
        int heartsYellow = class_3532.method_15386(healthYellow / 2.0F);
        boolean lastYellowHalf = (healthYellow & 1) == 1;
        int heartsTotal = heartsNormal + heartsYellow;
        int heartsPerRow = ModConfig.HANDLER.instance().icons_per_row;
        int pixelsTotal = Math.min(heartsTotal, heartsPerRow) * 8 + 1;
        float maxX = pixelsTotal / 2.0f;
        float scale = ModConfig.HANDLER.instance().size;
        double heartDensity = 50F - (Math.max(4F - Math.ceil((double) heartsTotal / heartsPerRow), -3F) * 5F);
        double h = 0;
        // Check if entity is obstructed by blocks
        boolean shouldRenderThroughWalls = false;
        for (int isDrawingEmpty = 0; isDrawingEmpty < 2; isDrawingEmpty++) {
            //   Order 1: Empty hearts (background)
            //   Order 2: Filled hearts (foreground)
            class_11785 targetQueue = shouldRenderThroughWalls ? 
                orderedRenderCommandQueue.method_73529(isDrawingEmpty) : 
                orderedRenderCommandQueue;
            
            for (int heart = 0; heart < heartsTotal; heart++) {
                if (heart % heartsPerRow == 0) {
                    h = heart / heartDensity;
                }
                matrixStack.method_22903();
                matrixStack.method_22904(0, livingEntity.method_17682() + 0.5f + h, 0);
                if (livingEntity.method_6059(class_1294.field_5924) && ModConfig.HANDLER.instance().show_heart_effects) {
                    if(HeartJumpData.getWhichHeartJumping(livingEntity) == heart){
                        matrixStack.method_22904(0.0D, 1.15F * scale, 0.0D);
                    }
                }
        if ((this.method_3921(entAsT, d)
                        || (ModConfig.HANDLER.instance().force_higher_offset_for_players && livingEntity instanceof class_1657 && livingEntity != client.field_1724))
                        && d <= 4096.0) {
                    matrixStack.method_22904(0.0D, 9.0F * 1.15F * scale, 0.0D);
                    if (d < 100.0 && livingEntity instanceof class_1657 && livingEntity.method_73183().method_8428().method_1189(net.minecraft.class_8646.field_45158) != null) {
                        matrixStack.method_22904(0.0D, 9.0F * 1.15F * scale, 0.0D);
                    }
                }
                matrixStack.method_22907(this.field_4676.field_4686.method_23767());
                matrixStack.method_22905(-scale, scale, scale);
                matrixStack.method_22904(0, ModConfig.getDisplayOffset(), 0);
                float x = maxX - (heart % heartsPerRow) * 8;
                if (isDrawingEmpty == 0) {
                    // Create heart texture identifier
                    String additionalIconEffects = "";
                    HeartTypeEnum type = HeartTypeEnum.EMPTY;
                    class_2960 heartTextureId = ModConfig.HANDLER.instance().use_vanilla_textures ?
                            class_2960.method_60655("healthindicators", "textures/gui/heart/" + additionalIconEffects + type.icon + ".png") :
                            class_2960.method_60655("minecraft", "textures/gui/sprites/hud/heart/" + additionalIconEffects + type.icon + ".png");
                    // Get vertex consumer for this specific texture with appropriate render layer
                    class_1921 renderLayer;
                    if (shouldRenderThroughWalls) {
                        // Use see-through render layer
                        renderLayer = class_12249.method_76028(heartTextureId);
                    } else {
                        // Use normal text render layer
                        renderLayer = class_12249.method_76022(heartTextureId);
                    }
                    final HeartTypeEnum renderType = type;
                    float opacity = ModConfig.HANDLER.instance().health_bar_opacity / 100.0F;
                        targetQueue.method_73483(matrixStack, renderLayer, (matricesEntry, vertexConsumer) -> {
                            Matrix4f m = matricesEntry.method_23761();
                            RenderUtils.drawHeart(m, vertexConsumer, x, renderType, livingEntity, opacity, d, shouldRenderThroughWalls);
                        });
                } else {
                    HeartTypeEnum type;
                    if (heart < heartsRed) {
                        type = HeartTypeEnum.RED_FULL;
                        if (heart == heartsRed - 1 && lastRedHalf) {
                            type = HeartTypeEnum.RED_HALF;
                        }
                    } else if (heart < heartsNormal) {
                        type = HeartTypeEnum.EMPTY;
                    } else {
                        type = HeartTypeEnum.YELLOW_FULL;
                        if (heart == heartsTotal - 1 && lastYellowHalf) {
                            type = HeartTypeEnum.YELLOW_HALF;
                        }
                    }
                    if (type != HeartTypeEnum.EMPTY) {
                        // Create heart texture identifier with effects
                        String additionalIconEffects = "";
                        if(type != HeartTypeEnum.YELLOW_FULL && type != HeartTypeEnum.YELLOW_HALF && type != HeartTypeEnum.EMPTY && ModConfig.HANDLER.instance().show_heart_effects) {
                            additionalIconEffects = (addStatusIcon(livingEntity) + addHardcoreIcon(livingEntity));
                        }
                        class_2960 heartTextureId = ModConfig.HANDLER.instance().use_vanilla_textures ?
                                class_2960.method_60655("healthindicators", "textures/gui/heart/" + additionalIconEffects + type.icon + ".png") :
                                class_2960.method_60655("minecraft", "textures/gui/sprites/hud/heart/" + additionalIconEffects + type.icon + ".png");
                        class_1921 renderLayer;
                        if (shouldRenderThroughWalls) {
                            renderLayer = class_12249.method_76028(heartTextureId);
                        } else {
                            renderLayer = class_12249.method_76022(heartTextureId);
                        }
                        final HeartTypeEnum renderType = type;
                        float opacity = ModConfig.HANDLER.instance().health_bar_opacity / 100.0F;
                        targetQueue.method_73483(matrixStack, renderLayer, (matricesEntry, vertexConsumer) -> {
                            Matrix4f m = matricesEntry.method_23761();
                            RenderUtils.drawHeart(m, vertexConsumer, x, renderType, livingEntity, opacity, d, shouldRenderThroughWalls);
                        });
                    }
                }
                matrixStack.method_22909();
            }
        }
    }
    @SuppressWarnings("unchecked")
    @Unique
    private void renderNumber(class_1309 livingEntity, float yaw, float tickDelta, class_4587 matrixStack, class_11659 orderedRenderCommandQueue){
        double d = this.field_4676.method_23168(livingEntity);
        final T entAsT = (T) livingEntity;
        String healthText = RenderUtils.getHealthText(livingEntity);
        boolean shouldRenderThroughWalls = false;
        matrixStack.method_22903();
        float scale = ModConfig.HANDLER.instance().size;
        matrixStack.method_46416(0, livingEntity.method_17682() + 0.5f, 0);
    if ((this.method_3921(entAsT, d)
                || (ModConfig.HANDLER.instance().force_higher_offset_for_players && livingEntity instanceof class_1657 && livingEntity != client.field_1724))
                && d <= 4096.0) {
            matrixStack.method_22904(0.0D, 9.0F * 1.15F * scale, 0.0D);
            if (d < 100.0 && livingEntity instanceof class_1657 && livingEntity.method_73183().method_8428().method_1189(net.minecraft.class_8646.field_45158) != null) {
                matrixStack.method_22904(0.0D, 9.0F * 1.15F * scale, 0.0D);
            }
        }
        matrixStack.method_22907(this.field_4676.field_4686.method_23767());
        matrixStack.method_22905(scale, -scale, scale);
        matrixStack.method_22904(0, ModConfig.getDisplayOffset(), 0);
        class_327 textRenderer = class_310.method_1551().field_1772;
        float x = -textRenderer.method_1727(healthText) / 2.0f;
    class_327.class_6415 textLayerType = shouldRenderThroughWalls ?
        class_327.class_6415.field_33994 : class_327.class_6415.field_33993;
    int backgroundColor = ModConfig.HANDLER.instance().render_number_display_background_color ?
        ModConfig.HANDLER.instance().number_display_background_color.getRGB() : 0;

    int textColor = ModConfig.HANDLER.instance().number_color.getRGB();
    int opacity = ModConfig.HANDLER.instance().health_bar_opacity;
    textColor = (textColor & 0x00FFFFFF) | ((opacity * 255 / 100) << 24);

    orderedRenderCommandQueue.method_73478(
        matrixStack,
        x,
        0.0F,
        class_2561.method_43470(healthText).method_30937(),
        ModConfig.HANDLER.instance().render_number_display_shadow,
        textLayerType,
        15728880,
        textColor,
        backgroundColor,
        0
    );
        matrixStack.method_22909();
    }
    @SuppressWarnings("unchecked")
    @Unique private void renderArmorPoints(class_1309 livingEntity, float yaw, float tickDelta, class_4587 matrixStack, class_11659 orderedRenderCommandQueue){
        double d = this.field_4676.method_23168(livingEntity);
        final T entAsT = (T) livingEntity;
        int armor = class_3532.method_15386(livingEntity.method_6096());
        int maxArmor = class_3532.method_15386(livingEntity.method_6096());
        if(maxArmor == 0) return;
        int armorPoints = class_3532.method_15386(armor / 2.0F);
        boolean lastPointHalf = (armor & 1) == 1;
    int pointsTotal = 10;
        int pointsPerRow = ModConfig.HANDLER.instance().icons_per_row;
        int pixelsTotal = Math.min(pointsTotal, pointsPerRow) * 8 + 1;
        float maxX = pixelsTotal / 2.0f;
        float scale = ModConfig.HANDLER.instance().size;
        // Check if entity is obstructed by blocks
        boolean shouldRenderThroughWalls = false;
    double h = 0;
        
        for (int isDrawingEmpty = 0; isDrawingEmpty < 2; isDrawingEmpty++) {
            // Again, switch to batching queues for see-through mode
            class_11785 targetQueue = shouldRenderThroughWalls ? 
                orderedRenderCommandQueue.method_73529(isDrawingEmpty + 2) : 
                orderedRenderCommandQueue;
            
            for (int pointCount = 0; pointCount < pointsTotal; pointCount++) {
                if (pointCount % pointsPerRow == 0) {
                    h = (scale*10)*((pointCount/2 + pointsPerRow - 1) / pointsPerRow);
                }
                matrixStack.method_22903();
                int extraHeight = (int) (((livingEntity.method_6063() + livingEntity.method_6067())/2 + pointsPerRow - 1) / pointsPerRow);
                matrixStack.method_22904(0, livingEntity.method_17682() + 0.75f + (scale*10)*(extraHeight-1) + h, 0);
        if ((this.method_3921(entAsT, d)
                        || (ModConfig.HANDLER.instance().force_higher_offset_for_players && livingEntity instanceof class_1657 && livingEntity != client.field_1724))
                        && d <= 4096.0) {
                    matrixStack.method_22904(0.0D, 9.0F * 1.15F * scale, 0.0D);
                    if (d < 100.0 && livingEntity instanceof class_1657 && livingEntity.method_73183().method_8428().method_1189(net.minecraft.class_8646.field_45158) != null) {
                        matrixStack.method_22904(0.0D, 9.0F * 1.15F * scale, 0.0D);
                    }
                }
                matrixStack.method_22907(this.field_4676.field_4686.method_23767());
                matrixStack.method_22905(-scale, scale, scale);
                matrixStack.method_22904(0, ModConfig.getDisplayOffset(), 0);
                float x = maxX - (pointCount % pointsPerRow) * 8;
                ArmorTypeEnum type = (isDrawingEmpty == 0) ? ArmorTypeEnum.EMPTY : (pointCount < armorPoints ? ((pointCount == armorPoints - 1 && lastPointHalf) ? ArmorTypeEnum.HALF : ArmorTypeEnum.FULL) : null);
                if (type != null) {
                    class_2960 armorTextureId = type.icon;

                    class_1921 renderLayer;
                    if (shouldRenderThroughWalls) {
                        // Use see-through render layer
                        //renderLayer = RenderLayer.getTextSeeThrough(armorTextureId);
                        renderLayer = class_12249.method_76028(armorTextureId);
                    } else {
                        // Use normal text render layer
                        renderLayer = class_12249.method_76022(armorTextureId);
                    }
                    final ArmorTypeEnum renderType = type;
                    float opacity = ModConfig.HANDLER.instance().health_bar_opacity / 100.0F;
                    targetQueue.method_73483(matrixStack, renderLayer, (matricesEntry, vertexConsumer) -> {
                        Matrix4f m = matricesEntry.method_23761();
                        RenderUtils.drawArmor(m, vertexConsumer, x, renderType, opacity, d, shouldRenderThroughWalls);
                    });
                }
                matrixStack.method_22909();
            }
        }
    }
}