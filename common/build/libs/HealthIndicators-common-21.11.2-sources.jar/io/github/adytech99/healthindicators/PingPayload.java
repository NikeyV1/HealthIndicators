package io.github.adytech99.healthindicators;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record PingPayload(String modVersion) implements class_8710 {
    public static final class_9154<PingPayload> ID =
            new class_9154<>(class_2960.method_60655("healthindicators", "handshake"));

    public static final class_9139<class_2540, PingPayload> CODEC =
            class_9139.method_56434(
                    class_9135.field_48554, PingPayload::modVersion,
                    PingPayload::new
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}