package io.github.adytech99.healthindicators.config;

import com.google.common.collect.Lists;
import dev.architectury.platform.Platform;
import dev.isxander.yacl3.config.v2.api.ConfigClassHandler;
import dev.isxander.yacl3.config.v2.api.SerialEntry;
import dev.isxander.yacl3.config.v2.api.autogen.*;
import dev.isxander.yacl3.config.v2.api.serializer.GsonConfigSerializerBuilder;
import io.github.adytech99.healthindicators.HealthIndicatorsCommon;
import io.github.adytech99.healthindicators.enums.HealthDisplayTypeEnum;
import io.github.adytech99.healthindicators.enums.MessageTypeEnum;
import org.jetbrains.annotations.Nullable;

import java.awt.*;
import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_437;

public class ModConfig {
    public static final Path CONFIG_PATH = Platform.getConfigFolder().resolve("health_indicators_config.json");

    public static final ConfigClassHandler<ModConfig> HANDLER = ConfigClassHandler.createBuilder(ModConfig.class)
            .id(class_2960.method_60655(HealthIndicatorsCommon.MOD_ID, "config"))
            .serializer(config -> GsonConfigSerializerBuilder.create(config)
                    .setPath(CONFIG_PATH)
                    .build())
            .build();

    @Label
    @AutoGen(category = "filters")
    private final class_2561 filtersProTip = class_2561.method_43470("Pro Tip: You can temporarily override the below criteria and force health display for all living entities by holding the Right-Arrow key (customizable)").method_27692(class_124.field_1065);

    @Label
    //@AutoGen(category = "filters", group = "entity_type")
    private final class_2561 filtersTypeLabel = class_2561.method_43470("Enable health display based on entity type").method_27695(class_124.field_1067, class_124.field_1075);

    @SerialEntry
    @AutoGen(category = "filters", group = "entity_type")
    @TickBox
    public boolean passive_mobs = true;

    @SerialEntry
    @AutoGen(category = "filters", group = "entity_type")
    @TickBox
    public boolean hostile_mobs = true;

    @SerialEntry
    @AutoGen(category = "filters", group = "entity_type")
    @MasterTickBox(value = "override_players")
    public boolean players = true;

    @SerialEntry
    @AutoGen(category = "filters", group = "entity_type")
    @TickBox
    public boolean self = false;

    @SerialEntry
    @AutoGen(category = "filters")
    @Boolean(formatter = Boolean.Formatter.CUSTOM)
    public boolean blacklistOrWhitelist = true;

    @SerialEntry
    @AutoGen(category = "filters")
    @ListGroup(valueFactory = EntitiesListGroup.class, controllerFactory = EntitiesListGroup.class)
    public List<String> list = Lists.newArrayList("minecraft:armor_stand");


    @Label
    @AutoGen(category = "filters", group = "advanced")
    private final class_2561 filtersAdvancedLabel = class_2561.method_43470("Show for...").method_27692(class_124.field_1075);

    /*@Label
    @AutoGen(category = "filters", group = "advanced")
    //private final Text after_attack_label = Text.literal("Settings for the 'Show on attack' criteria:").formatted(Formatting.ITALIC);
    private final Text after_attack_label = Text.literal(" ").formatted(Formatting.ITALIC);*/

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @MasterTickBox(value = {"override_players", "time_after_hit"})
    public boolean after_attack = false;

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @IntSlider(min = 0, max = 120, step = 1)
    public int time_after_hit = 60;

    @Label
    @AutoGen(category = "filters", group = "advanced")
    //private final Text damaged_only_label = Text.literal("Settings for the 'damaged entity' criteria:").formatted(Formatting.ITALIC);
    private final class_2561 damaged_only_label = class_2561.method_43470(" ").method_27692(class_124.field_1056);

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @MasterTickBox(value = {"override_players", "max_health_percentage"})
    public boolean damaged_only = false;

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @IntSlider(min = 0, max = 100, step = 1)
    public int max_health_percentage = 100;

    @Label
    @AutoGen(category = "filters", group = "advanced")
    //private final Text on_crosshair_label = Text.literal("Settings for the 'looking at entity' criteria:").formatted(Formatting.ITALIC);
    private final class_2561 looking_at_label = class_2561.method_43470(" ").method_27692(class_124.field_1056);

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @MasterTickBox(value = {"override_players", "reach"})
    public boolean looking_at = false;

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @IntField(min = 0, max = 1024)
    public int reach = 3;

    @Label
    @AutoGen(category = "filters", group = "advanced")
    private final class_2561 distance_label = class_2561.method_43470(" ").method_27692(class_124.field_1056);

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @MasterTickBox(value = {"override_players", "distance"})
    public boolean within_distance = false;

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @IntSlider(min = 0, max = 512, step = 4)
    public int distance = 64;


    @Label
    @AutoGen(category = "filters", group = "advanced")
    private final class_2561 override_players_label = class_2561.method_43470("Overrides").method_27692(class_124.field_1056);

    @SerialEntry
    @AutoGen(category = "filters", group = "advanced")
    @TickBox
    public boolean override_players = false;


    //APPEARANCE


    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @EnumCycler
    public HealthDisplayTypeEnum indicator_type = HealthDisplayTypeEnum.HEARTS;

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @IntSlider(min = 10, max = 200, step = 2)
    public int dynamic_health_threshold = 100;

    @AutoGen(category = "appearance", group = "indicator_type")
    @Label
    private final class_2561 heart_type_settings_label = class_2561.method_43470("Settings for the heart-type indicator");

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @IntField
    public int icons_per_row = 10;

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @Boolean
    public boolean use_vanilla_textures = false;

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @IntSlider(min = 0, max = 100, step = 1)
    public int health_bar_opacity = 100;

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @Boolean
    public boolean show_heart_effects = true;

    @AutoGen(category = "appearance", group = "indicator_type")
    @Label
    private final class_2561 number_type_settings_label = class_2561.method_43470("Settings for the number-type indicator");

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @ColorField
    public Color number_color = Color.RED;

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @Boolean
    public boolean render_number_display_shadow = false;

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @IntSlider(min = 0, max = 12, step = 1)
    public int decimal_places = 1;

    /*@SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @MasterTickBox(value = {"number_display_background_color"})*/
    public boolean render_number_display_background_color = false;

    /*@SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @ColorField*/
    public Color number_display_background_color = Color.BLACK;

    @AutoGen(category = "appearance", group = "indicator_type")
    @Label
    private final class_2561 common_type_settings_label = class_2561.method_43470("Common settings for all indicator types");

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @MasterTickBox(value = {"max_health"})
    public boolean percentage_based_health = false;

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @IntSlider(min = 1, max = 100, step = 1)
    public int max_health = 20;

    @SerialEntry
    @AutoGen(category = "appearance", group = "indicator_type")
    @FloatSlider(min = 0.010f, max = 0.030f, step = 0.005f, format = "%.3f")
    public float size = 0.025f;


    @SerialEntry
    @AutoGen(category = "appearance", group = "offset")
    @DoubleField
    public double display_offset = 0;

    @SerialEntry
    @AutoGen(category = "appearance", group = "offset")
    @DoubleSlider(min = 0.0, max = 5.0, step = 0.5)
    public double offset_step_size = 1;

    @SerialEntry
    @AutoGen(category = "appearance", group = "offset")
    @Boolean
    public boolean force_higher_offset_for_players = false;


    //MESSAGES & COMMANDS


    @SerialEntry
    @AutoGen(category = "messages", group = "messages_appearance")
    @EnumCycler
    public MessageTypeEnum message_type = MessageTypeEnum.ACTIONBAR;

    @SerialEntry
    @AutoGen(category = "messages", group = "messages_appearance")
    @Boolean(colored = true)
    public boolean colored_messages = true;

    /*@SerialEntry
    @AutoGen(category = "appearance", group = "heart_offset")
    @Boolean
    public boolean hearts_clipping = true;*/

    //DAMAGE DIRECTION INDICATORS

    @SerialEntry
    @AutoGen(category = "damage_direction_indicators")
    @CustomImage(value = "images/damage_direction_indicator_example.png", width = 2160, height = 2160)
    @Boolean
    public boolean enable_damage_direction_indicators = false;

    @SerialEntry
    @AutoGen(category = "damage_direction_indicators")
    @IntSlider(min = 1, max = 8, step = 1)
    public int damage_direction_indicators_scale = 2;

    @SerialEntry
    @AutoGen(category = "damage_direction_indicators")
    @ColorField
    public Color damage_direction_indicators_color = Color.RED;

    @SerialEntry
    @AutoGen(category = "damage_direction_indicators")
    @IntSlider(min = 1, max = 8, step = 1)
    public int damage_direction_indicators_visibility_time = 4;

    @SerialEntry
    @AutoGen(category = "damage_direction_indicators")
    @MasterTickBox(value = "damage_direction_indicators_fade_out_time")
    public boolean damage_direction_indicators_fade_out = true;

    @SerialEntry
    @AutoGen(category = "damage_direction_indicators")
    @IntSlider(min = 0, max = 7, step = 1)
    public int damage_direction_indicators_fade_out_time = 3;


    public static class_437 createScreen(@Nullable class_437 parent) {
        return HANDLER.generateGui().generateScreen(parent);
    }
    public class_437 createConfigScreen(class_437 parent) {
        if (Platform.isModLoaded("yet_another_config_lib_v3")) {
            return createScreen(parent);
        }
        return null;
    }

    // Hinzufügen:
    public static double getDisplayOffset() {
        return Math.clamp(HANDLER.instance().display_offset, -5.0, 5.0);
    }

    public static float getSize() {
        return Math.clamp(HANDLER.instance().size, 0.010f, 0.030f);
    }

}
