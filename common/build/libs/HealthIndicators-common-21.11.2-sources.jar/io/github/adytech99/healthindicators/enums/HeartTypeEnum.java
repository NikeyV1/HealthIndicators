package io.github.adytech99.healthindicators.enums;

import net.minecraft.class_1294;
import net.minecraft.class_1309;

public enum HeartTypeEnum {
    EMPTY("container"),
    RED_FULL("full"),
    RED_HALF("half"),
    YELLOW_FULL("absorbing_full"),
    YELLOW_HALF("absorbing_half");

    public final String icon;

    HeartTypeEnum(String heartIcon) {
        icon = heartIcon;
    }

    public static String addStatusIcon(class_1309 livingEntity){
        if (livingEntity.method_6059(class_1294.field_5920)) return "withered_";
        if (livingEntity.method_6059(class_1294.field_5899)) return "poisoned_";
        if (livingEntity.method_32314()) return "frozen_";
        else return "";
    }


    public static String addHardcoreIcon(class_1309 livingEntity){
        if (livingEntity.method_73183().method_8401().method_152()) return "hardcore_";
        else return "";
    }
}