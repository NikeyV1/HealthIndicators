package io.github.adytech99.healthindicators;

import io.github.adytech99.healthindicators.config.ModConfig;
import java.awt.*;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public class DamageDirectionIndicatorRenderer {
    private static class_1657 player = HealthIndicatorsCommon.client.field_1724;
    private static int timeSinceLastDamage = Integer.MAX_VALUE;
    private static class_1309 attacker;

    public static void markDamageToPlayer(class_1309 livingEntity){
        timeSinceLastDamage = 0;
        attacker = livingEntity;
    }

    public static void tick(){
        player = HealthIndicatorsCommon.client.field_1724;
        if(timeSinceLastDamage != Integer.MAX_VALUE) timeSinceLastDamage++;
        if (attacker == null || attacker.method_29504() || attacker.method_31481()){
            timeSinceLastDamage = Integer.MAX_VALUE;
            attacker = null;
        }
        if(timeSinceLastDamage == Integer.MAX_VALUE) attacker = null;
    }

    public static void render(class_332 drawContext, float tickDelta) {
        if (player == null) return;
        if (timeSinceLastDamage <= ModConfig.HANDLER.instance().damage_direction_indicators_visibility_time * 20 && attacker != null) {
            // Get positions and calculate direction
            class_243 playerPos = player.method_73189();
            class_243 attackerPos = attacker.method_73189();
            double deltaX = attackerPos.field_1352 - playerPos.field_1352;
            double deltaZ = attackerPos.field_1350 - playerPos.field_1350;

            // Calculate yaw to attacker and delta from player's current view
            float yawToAttacker = (float) Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0f;
            yawToAttacker = class_3532.method_15393(yawToAttacker);
            float deltaYaw = class_3532.method_15393(yawToAttacker - player.method_36454());

            // Get screen center and setup parameters
            int centerX = drawContext.method_51421() / 2;
            int centerY = drawContext.method_51443() / 2;
            float angle = (float) Math.toRadians(deltaYaw);

            // Calculate fade-out alpha (0-255)
            int alpha = 255;
            if (ModConfig.HANDLER.instance().damage_direction_indicators_fade_out) {
                int fadeDelay = (ModConfig.HANDLER.instance().damage_direction_indicators_visibility_time - ModConfig.HANDLER.instance().damage_direction_indicators_fade_out_time) * 20;
                if (timeSinceLastDamage >= fadeDelay) {
                    float progress = Math.min((timeSinceLastDamage - fadeDelay) / (float) (ModConfig.HANDLER.instance().damage_direction_indicators_fade_out_time * 20), 1.0f);
                    alpha = 255 - (int) (255 * progress);
                }
            }

            float scale = ModConfig.HANDLER.instance().damage_direction_indicators_scale;
            Color color = ModConfig.HANDLER.instance().damage_direction_indicators_color;

            // Draw the curved arc indicator
            drawArcIndicator(drawContext, centerX, centerY, angle, scale, color, alpha);
        }
    }

    private static void drawArcIndicator(class_332 context, int centerX, int centerY, float directionAngle, float scale, Color color, int alpha) {
        // Parameters for the curved arc indicator
        // radians
        float radius = 28.0f * scale; // Distance from center
        float arcSpan = 50.0f; // Arc width in degrees
        float thickness = 1.6f * scale; // Thickness of the arc
        int segments = 20; // Number of segments for smooth curve

        // Create color with alpha for main arc
        int mainColor = (alpha << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();

        // Create slightly darker color for outer edge (subtle depth effect)
        int darkerAlpha = (int)(alpha * 0.25f);
        int darkerColor = (darkerAlpha << 24) | ((color.getRed() * 2 / 3) << 16) | ((color.getGreen() * 2 / 3) << 8) | (color.getBlue() * 2 / 3);

        // Draw the main arc as a series of connected quads
        for (int i = 0; i < segments; i++) {
            float t1 = (float)i / segments;
            float t2 = (float)(i + 1) / segments;

            // Calculate angles for this segment (centered on direction angle)
            float angle1 = directionAngle - (float)Math.toRadians(arcSpan / 2.0f) + (float)Math.toRadians(arcSpan * t1);
            float angle2 = directionAngle - (float)Math.toRadians(arcSpan / 2.0f) + (float)Math.toRadians(arcSpan * t2);

            // Inner arc points
            float x1Inner = centerX + radius * class_3532.method_15374(angle1);
            float y1Inner = centerY - radius * class_3532.method_15362(angle1);
            float x2Inner = centerX + radius * class_3532.method_15374(angle2);
            float y2Inner = centerY - radius * class_3532.method_15362(angle2);

            // Outer arc points
            float x1Outer = centerX + (radius + thickness) * class_3532.method_15374(angle1);
            float y1Outer = centerY - (radius + thickness) * class_3532.method_15362(angle1);
            float x2Outer = centerX + (radius + thickness) * class_3532.method_15374(angle2);
            float y2Outer = centerY - (radius + thickness) * class_3532.method_15362(angle2);

            // Draw quad for this segment
            drawQuad(context, x1Inner, y1Inner, x2Inner, y2Inner, x2Outer, y2Outer, x1Outer, y1Outer, mainColor);
        }

        // Draw subtle glow/shadow on outer edge for depth
        for (int i = 0; i < segments; i++) {
            float t1 = (float)i / segments;
            float t2 = (float)(i + 1) / segments;

            float angle1 = directionAngle - (float)Math.toRadians(arcSpan / 2.0f) + (float)Math.toRadians(arcSpan * t1);
            float angle2 = directionAngle - (float)Math.toRadians(arcSpan / 2.0f) + (float)Math.toRadians(arcSpan * t2);

            float x1 = centerX + (radius + thickness) * class_3532.method_15374(angle1);
            float y1 = centerY - (radius + thickness) * class_3532.method_15362(angle1);
            float x2 = centerX + (radius + thickness) * class_3532.method_15374(angle2);
            float y2 = centerY - (radius + thickness) * class_3532.method_15362(angle2);

            float x1Outer = centerX + (radius + thickness + 1.0f * scale) * class_3532.method_15374(angle1);
            float y1Outer = centerY - (radius + thickness + 1.0f * scale) * class_3532.method_15362(angle1);
            float x2Outer = centerX + (radius + thickness + 1.0f * scale) * class_3532.method_15374(angle2);
            float y2Outer = centerY - (radius + thickness + 1.0f * scale) * class_3532.method_15362(angle2);

            drawQuad(context, x1, y1, x2, y2, x2Outer, y2Outer, x1Outer, y1Outer, darkerColor);
        }

        // Draw arrow pointer at the center of the arc pointing inward
        drawArrowPointer(context, centerX, centerY, directionAngle, radius, scale, color, alpha);
    }

    private static void drawArrowPointer(class_332 context, int centerX, int centerY, float directionAngle, float radius, float scale, Color color, int alpha) {
        // Arrow dimensions
        float arrowLength = 6.0f * scale;
        float arrowWidth = 4.5f * scale;

        // Position arrow at outer edge of arc
        float arrowBaseX = centerX + radius * class_3532.method_15374(directionAngle);
        float arrowBaseY = centerY - radius * class_3532.method_15362(directionAngle);

        // Calculate arrow tip pointing OUTWARD (away from center)
        float arrowTipX = centerX + (radius + arrowLength) * class_3532.method_15374(directionAngle);
        float arrowTipY = centerY - (radius + arrowLength) * class_3532.method_15362(directionAngle);

        // Calculate perpendicular angle for arrow wings
        float perpAngle = directionAngle + (float)Math.PI / 2.0f;

        // Arrow wing points
        float leftWingX = arrowBaseX + arrowWidth * class_3532.method_15374(perpAngle);
        float leftWingY = arrowBaseY - arrowWidth * class_3532.method_15362(perpAngle);
        float rightWingX = arrowBaseX - arrowWidth * class_3532.method_15374(perpAngle);
        float rightWingY = arrowBaseY + arrowWidth * class_3532.method_15362(perpAngle);

        // Create color with alpha
        int arrowColor = (alpha << 24) | (color.getRed() << 16) | (color.getGreen() << 8) | color.getBlue();

        // Draw arrow as a triangle
        float[] xs = {arrowTipX, leftWingX, rightWingX};
        float[] ys = {arrowTipY, leftWingY, rightWingY};
        sortVerticesByY(xs, ys);
        drawTriangle(context, xs, ys, arrowColor);
    }

    private static void drawQuad(class_332 context, float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4, int color) {
        // Draw quad as two triangles
        float[] tri1X = {x1, x2, x3};
        float[] tri1Y = {y1, y2, y3};
        float[] tri2X = {x1, x3, x4};
        float[] tri2Y = {y1, y3, y4};

        sortVerticesByY(tri1X, tri1Y);
        drawTriangle(context, tri1X, tri1Y, color);

        sortVerticesByY(tri2X, tri2Y);
        drawTriangle(context, tri2X, tri2Y, color);
    }

    // Helper: Sort vertices by Y coordinate (ascending)
    private static void sortVerticesByY(float[] xs, float[] ys) {
        if (ys[0] > ys[1]) {
            swap(xs, ys, 0, 1);
        }
        if (ys[0] > ys[2]) {
            swap(xs, ys, 0, 2);
        }
        if (ys[1] > ys[2]) {
            swap(xs, ys, 1, 2);
        }
    }

    // Helper: Swap two vertices in arrays
    private static void swap(float[] xs, float[] ys, int i, int j) {
        float tx = xs[i];
        xs[i] = xs[j];
        xs[j] = tx;
        float ty = ys[i];
        ys[i] = ys[j];
        ys[j] = ty;
    }

    // Helper: Draw a filled triangle using scanline algorithm
    private static void drawTriangle(class_332 context, float[] xs, float[] ys, int color) {
        float minY = ys[0];
        float midY = ys[1];
        float maxY = ys[2];

        if (minY == maxY) return; // Degenerate triangle

        // Iterate over each scanline
        for (int y = (int) Math.floor(minY); y <= (int) Math.ceil(maxY); y++) {
            if (y < minY || y > maxY) continue;

            boolean inSecondHalf = y > midY;
            float xa, xb;

            if (!inSecondHalf) {
                // Between minY and midY
                xa = interpolate(xs[0], ys[0], xs[1], ys[1], y);
                xb = interpolate(xs[0], ys[0], xs[2], ys[2], y);
            } else {
                // Between midY and maxY
                xa = interpolate(xs[1], ys[1], xs[2], ys[2], y);
                xb = interpolate(xs[0], ys[0], xs[2], ys[2], y);
            }

            // Ensure left to right order
            if (xa > xb) {
                float tmp = xa;
                xa = xb;
                xb = tmp;
            }

            // Draw horizontal line segment
            context.method_25294((int) xa, y, (int) xb + 1, y + 1, color);
        }
    }

    // Helper: Linear interpolation for edge scanning
    private static float interpolate(float x1, float y1, float x2, float y2, float y) {
        if (y1 == y2) return x1;
        return x1 + (x2 - x1) * (y - y1) / (y2 - y1);
    }
}