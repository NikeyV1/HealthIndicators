package io.github.adytech99.healthindicators.util;

import io.github.adytech99.healthindicators.enums.MessageTypeEnum;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_746;
import io.github.adytech99.healthindicators.config.ModConfig;

public class ConfigUtils {
    public static void sendMessage(class_746 player, class_2561 text) {
        if (isSendMessage()) {
            boolean overlay = ModConfig.HANDLER.instance().message_type == MessageTypeEnum.ACTIONBAR;
            player.method_7353(text, overlay);
        }
    }

    public static void sendMessage(class_3222 player, class_2561 text) {
        if (isSendMessage()) {
            boolean overlay = ModConfig.HANDLER.instance().message_type == MessageTypeEnum.ACTIONBAR;
            player.method_7353(text, overlay);
        }
    }

    public static void sendOverlayMessage(class_746 player, class_2561 text) {
        if (isSendMessage()) {
            boolean overlay = ModConfig.HANDLER.instance().message_type == MessageTypeEnum.ACTIONBAR;
            player.method_7353(text, true);
        }
    }

    public static boolean isSendMessage() {
        return ModConfig.HANDLER.instance().message_type != MessageTypeEnum.NONE;
    }

}
