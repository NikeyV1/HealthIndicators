package io.github.adytech99.healthindicators.enums;

import dev.isxander.yacl3.api.NameableEnum;
import net.minecraft.class_2561;

public enum HealthDisplayTypeEnum implements NameableEnum {
    HEARTS("Hearts"),
    NUMBER("Number"),
    DYNAMIC("Dynamic");

    private final String displayName;
    HealthDisplayTypeEnum(String displayName) {
        this.displayName = displayName;
    }

    @Override
    public class_2561 getDisplayName() {
        return class_2561.method_30163(displayName);
    }
}
