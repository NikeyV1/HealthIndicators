package io.github.adytech99.healthindicators;

import io.github.adytech99.healthindicators.config.Config;
import io.github.adytech99.healthindicators.config.ModConfig;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_638;
import net.minecraft.class_746;

public class RenderTracker {
    private static final class_310 client = class_310.method_1551();
    private static final ConcurrentHashMap<UUID, Integer> UUIDS = new ConcurrentHashMap<>();
    public static boolean after_attack = ModConfig.HANDLER.instance().after_attack;

    private static class_1309 trackedEntity;

    public static class_1309 getTrackedEntity() {
        return trackedEntity;
    }

    public static void setTrackedEntity(class_1309 trackedEntity) {
        RenderTracker.trackedEntity = trackedEntity;
    }


    public static void tick(class_310 client){
        if(client.field_1724 == null || client.field_1687 == null) return;
        if(Config.getRenderingEnabled()) {
            for (class_1297 entity : client.field_1687.method_18112()) {
                if (entity instanceof class_1309 livingEntity && satisfiesAdvancedCriteria(client.field_1724, livingEntity) && satisfiesList(client.field_1724, livingEntity)) {
                    addToUUIDS(livingEntity);
                } else removeFromUUIDS(entity.method_5667());
            }
        }
        trimEntities(client.field_1687);
        if(ModConfig.HANDLER.instance().after_attack != after_attack) {
            UUIDS.clear();
            after_attack = ModConfig.HANDLER.instance().after_attack;
        }
        if(getTrackedEntity() == null || getTrackedEntity().method_29504() || getTrackedEntity().method_31481()) setTrackedEntity(null);
    }

    public static void onDamage(class_1282 damageSource, class_1309 livingEntity) {
        if(damageSource.method_5529() instanceof class_1657){
            assert client.field_1687 != null;
            if(ModConfig.HANDLER.instance().after_attack && livingEntity instanceof class_1309 && RenderTracker.isEntityTypeAllowed(livingEntity, client.field_1724) && satisfiesList(client.field_1724, livingEntity)) {
                //setTrackedEntity(livingEntity);
                if (!addToUUIDS(livingEntity)) {
                    UUIDS.replace(livingEntity.method_5667(), (ModConfig.HANDLER.instance().time_after_hit * 20));
                }
            }
        }
    }


    public static void trimEntities(class_638 world) {
        // Check if there's a need to trim entries
        Iterator<Map.Entry<UUID, Integer>> iterator = UUIDS.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Integer> entry = iterator.next();
            entry.setValue(entry.getValue() - 1);
            if (entry.getValue() <= 0) {
                iterator.remove(); // Safe removal during iteration
            }
        }

        // Remove invalid entities
        UUIDS.entrySet().removeIf(entry -> isInvalid(getEntityFromUUID(entry.getKey(), world))|| !Config.getRenderingEnabled() );
        if(UUIDS.size() >= 1536) UUIDS.clear();
    }


    public static void removeFromUUIDS(class_1297 entity){
        UUIDS.remove(entity.method_5667());
    }
    public static void removeFromUUIDS(UUID uuid){
        UUIDS.remove(uuid);
    }

    public static boolean addToUUIDS(class_1309 livingEntity){
        if(!UUIDS.containsKey(livingEntity.method_5667())){
            UUIDS.put(livingEntity.method_5667(), ModConfig.HANDLER.instance().after_attack ? (ModConfig.HANDLER.instance().time_after_hit * 20) : 2400);
            return true;
        }
        else return false;
    }

    public static boolean isInUUIDS(class_1309 livingEntity){
        return UUIDS.containsKey(livingEntity.method_5667());
    }

    public static boolean overridePlayers(class_746 playerEntity, class_1309 livingEntity){
        return (ModConfig.HANDLER.instance().override_players && livingEntity instanceof class_1657 && livingEntity != client.field_1724)
                || (livingEntity == client.field_1724 && ModConfig.HANDLER.instance().self);
    }

    public static boolean isEntityTypeAllowed(class_1309 livingEntity, class_1657 self){
        if(!ModConfig.HANDLER.instance().passive_mobs && livingEntity instanceof class_1296) return false;
        if(!ModConfig.HANDLER.instance().hostile_mobs && livingEntity instanceof class_1588) return false;
        if(!ModConfig.HANDLER.instance().players && livingEntity instanceof class_1657) return false;
        if(!ModConfig.HANDLER.instance().self && livingEntity == self) return false;
        return true;
    }

    public static boolean satisfiesAdvancedCriteria(class_746 player, class_1309 livingEntity){
        if(overridePlayers(player, livingEntity)) return true;

        if(!isEntityTypeAllowed(livingEntity, player)) return false; //Entity Types
        if(ModConfig.HANDLER.instance().after_attack && !UUIDS.containsKey(livingEntity.method_5667())) return false; //Damaged by Player, key should have been added by separate means. Necessary because removal check is done by this method.
        if(ModConfig.HANDLER.instance().damaged_only && (livingEntity.method_6032() == livingEntity.method_6063() || livingEntity.method_6032() > livingEntity.method_6063()*((float) ModConfig.HANDLER.instance().max_health_percentage / 100)) && livingEntity.method_6067() <= 0) return false; //Damaged by Any Reason
        if(ModConfig.HANDLER.instance().looking_at && !isTargeted(livingEntity)) return false;
        if(ModConfig.HANDLER.instance().within_distance && livingEntity.method_5739(player) > ModConfig.HANDLER.instance().distance) return false;

        return !isInvalid(livingEntity);
    }

    public static boolean satisfiesList(class_746 player, class_1309 livingEntity){
        if(!ModConfig.HANDLER.instance().blacklistOrWhitelist){
            if(ModConfig.HANDLER.instance().list.isEmpty()) return true;
            if(ModConfig.HANDLER.instance().list.contains("minecraft:player") && livingEntity instanceof class_1657) return true;
        }

        String[] blacklist1 = new String[ModConfig.HANDLER.instance().list.size()];
        for(int i = 0; i < ModConfig.HANDLER.instance().list.size(); i++){
            blacklist1[i] = ModConfig.HANDLER.instance().list.get(i);
        }

        if(ModConfig.HANDLER.instance().blacklistOrWhitelist) return Arrays.stream(blacklist1).noneMatch(s -> {
            if(livingEntity instanceof class_1657) return class_2561.method_30163(s).equals(Objects.requireNonNull(livingEntity.method_5477()));
            else return s.equals(class_1299.method_5890(livingEntity.method_5864()).toString());
        });
        else return Arrays.stream(blacklist1).anyMatch(s -> {
            if(livingEntity instanceof class_1657) return class_2561.method_30163(s).equals(Objects.requireNonNull(livingEntity.method_5477()));
            else return s.equals(class_1299.method_5890(livingEntity.method_5864()).toString());
        });
    }

    public static boolean isTargeted(class_1309 livingEntity){
        class_1297 camera = client.method_1560();
        double d = ModConfig.HANDLER.instance().reach;
        double e = class_3532.method_33723(d);
        class_243 vec3d = camera.method_5836(0);
        class_239 hitResult = camera.method_5745(d, 0, false);
        double f = hitResult.method_17784().method_1025(vec3d);
        if (hitResult.method_17783() != class_239.class_240.field_1333) {
            e = f;
            d = Math.sqrt(e);
        }
        class_243 vec3d2 = camera.method_5828(0);
        class_243 vec3d3 = vec3d.method_1031(vec3d2.field_1352 * d, vec3d2.field_1351 * d, vec3d2.field_1350 * d);
        float g = 1.0f;
        class_238 box = camera.method_5829().method_18804(vec3d2.method_1021(d)).method_1009(1.0, 1.0, 1.0);
        assert client.method_1560() != null;
        class_3966 entityHitResult = class_1675.method_18075(client.method_1560(), vec3d, vec3d3, box, entity -> !entity.method_7325() && entity.method_5863(), e);

        if (entityHitResult != null && entityHitResult.method_17782() instanceof class_1309 livingEntity1){
            return livingEntity1 == livingEntity;
        }
        return false;
    }

    public static boolean isOkayToRenderThroughWalls(class_1309 livingEntity){
        return isTargeted(livingEntity) && !livingEntity.method_31747();
    }

    public static boolean isInvalid(class_1297 entity){
        return (entity == null
                || !entity.method_5805()
                || !entity.method_5709()
                || entity.method_33724()
                || !(entity instanceof class_1309)
                || client.field_1724 == null
                || client.field_1724.method_5854() == entity
                || entity.method_5756(client.field_1724));
    }
    private static class_1297 getEntityFromUUID(UUID uuid, class_638 world) {
        for (class_1297 entity : world.method_18112()) {
            if (entity.method_5667().equals(uuid)) {
                return entity;
            }
        }
        return null;
    }
}

