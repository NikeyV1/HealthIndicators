package io.github.adytech99.healthindicators.util;

import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_638;

public class Util {
    public static double truncate(double number, int places) {
        return Math.floor(number * Math.pow(10, places)) / Math.pow(10, places);
    }

    public static class_1297 getEntityFromName(class_638 world, String entity_name){
        for(class_1297 entity : world.method_18112()){
            if(entity.method_16914()) if(Objects.equals(entity.method_5797().method_54160(), entity_name)) return entity;
            if(entity.method_31747()) if(Objects.equals(entity.method_5476().getString(), entity_name)) return entity;
        }
        return null;
    }
}
