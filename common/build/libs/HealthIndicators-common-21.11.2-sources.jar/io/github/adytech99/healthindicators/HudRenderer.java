package io.github.adytech99.healthindicators;

import com.mojang.blaze3d.systems.RenderSystem;
import io.github.adytech99.healthindicators.config.ModConfig;
import io.github.adytech99.healthindicators.util.RenderUtils;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5819;
import net.minecraft.class_9779;
import net.minecraft.client.render.*;
import java.awt.*;


public class HudRenderer {

    //public static DrawContext drawContext;
    //public static RenderTickCounter renderTickCounter;
    private static final class_5819 random = class_5819.method_43047();

    /*public static void onHudRender(LivingEntity livingEntity, double squaredDistanceToCamera, boolean hasLabel, Quaternionf rotation) {
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder vertexConsumer;
        MatrixStack matrixStack = drawContext.getMatrices();

        int healthRed = MathHelper.ceil(livingEntity.getHealth());
        int maxHealth = MathHelper.ceil(livingEntity.getMaxHealth());
        int healthYellow = MathHelper.ceil(livingEntity.getAbsorptionAmount());

        if(ModConfig.HANDLER.instance().percentage_based_health) {
            healthRed = MathHelper.ceil(((float) healthRed /maxHealth) * ModConfig.HANDLER.instance().max_health);
            maxHealth = MathHelper.ceil(ModConfig.HANDLER.instance().max_health);
            healthYellow = MathHelper.ceil(livingEntity.getAbsorptionAmount());
        }

        int heartsRed = MathHelper.ceil(healthRed / 2.0F);
        boolean lastRedHalf = (healthRed & 1) == 1;
        int heartsNormal = MathHelper.ceil(maxHealth / 2.0F);
        int heartsYellow = MathHelper.ceil(healthYellow / 2.0F);
        boolean lastYellowHalf = (healthYellow & 1) == 1;
        int heartsTotal = heartsNormal + heartsYellow;

        int heartsPerRow = ModConfig.HANDLER.instance().icons_per_row;
        int pixelsTotal = Math.min(heartsTotal, heartsPerRow) * 8 + 1;
        float maxX = pixelsTotal / 2.0f;

        for (int isDrawingEmpty = 0; isDrawingEmpty < 2; isDrawingEmpty++) {
            for (int heart = 0; heart < heartsTotal; heart++) {
                matrixStack.push();
                float scale = ModConfig.HANDLER.instance().size;
                vertexConsumer = tessellator.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);

                //matrixStack.translate(0, livingEntity.getHeight() + 0.5f + h, 0);

                if (livingEntity.hasStatusEffect(StatusEffects.REGENERATION) && ModConfig.HANDLER.instance().show_heart_effects) {
                    if(HeartJumpData.getWhichHeartJumping(livingEntity) == heart){
                        //matrixStack.translate(0.0D, 1.15F * scale, 0.0D);
                    }
                }

                if ((hasLabel
                        || (ModConfig.HANDLER.instance().force_higher_offset_for_players && livingEntity instanceof PlayerEntity && livingEntity != MinecraftClient.getInstance().player))
                        && squaredDistanceToCamera <= 4096.0) {
                    //matrixStack.translate(0.0D, 9.0F * 1.15F * scale, 0.0D);
                    if (squaredDistanceToCamera < 100.0 && livingEntity instanceof PlayerEntity && livingEntity.getEntityWorld().getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME) != null) {
                        //matrixStack.translate(0.0D, 9.0F * 1.15F * scale, 0.0D);
                    }
                }

                //matrixStack.multiply(rotation);
                if(MinecraftClient.getInstance().player != null) matrixStack.multiply(MinecraftClient.getInstance().player.getFacing().getRotationQuaternion());
                matrixStack.scale(-scale, scale, scale);
                //matrixStack.translate(0, ModConfig.HANDLER.instance().display_offset, 0);
                Matrix4f model = matrixStack.peek().getPositionMatrix();

                float x = maxX - (heart % heartsPerRow) * 8;

                if (isDrawingEmpty == 0) {
                    drawHeart(model, vertexConsumer, x, HeartTypeEnum.EMPTY, livingEntity);
                } else {
                    HeartTypeEnum type;
                    if (heart < heartsRed) {
                        type = HeartTypeEnum.RED_FULL;
                        if (heart == heartsRed - 1 && lastRedHalf) {
                            type = HeartTypeEnum.RED_HALF;
                        }
                    } else if (heart < heartsNormal) {
                        type = HeartTypeEnum.EMPTY;
                    } else {
                        type = HeartTypeEnum.YELLOW_FULL;
                        if (heart == heartsTotal - 1 && lastYellowHalf) {
                            type = HeartTypeEnum.YELLOW_HALF;
                        }
                    }
                    if (type != HeartTypeEnum.EMPTY) {
                        drawHeart(model, vertexConsumer, x, type, livingEntity);
                    }
                }

                BuiltBuffer builtBuffer;
                try {
                    builtBuffer = vertexConsumer.endNullable();
                    if(builtBuffer != null){
                        BufferRenderer.drawWithGlobalProgram(builtBuffer);
                        builtBuffer.close();
                    }
                }
                catch (Exception e){
                    // F off
                }
                matrixStack.pop();
            }
        }
    }*/


    public static void onHudRender(class_332 drawContext, class_9779 renderTickCounter){
        drawNumberHealthGUIIndicator(RenderTracker.getTrackedEntity(), ModConfig.HANDLER.instance().number_color, 20, 20, ModConfig.HANDLER.instance().render_number_display_shadow, drawContext);
    }


    /*public static void renderHealthBar(LivingEntity livingEntity, int lines, int regeneratingHeartIndex, float maxHealth, int lastHealth, int health, int absorption, boolean blinking) {
        HudHeartType heartType = HudHeartType.fromEntityState(livingEntity);
        boolean bl = livingEntity.getWorld().getLevelProperties().isHardcore();
        int i = MathHelper.ceil((double)maxHealth / 2.0);
        int j = MathHelper.ceil((double)absorption / 2.0);
        int k = i * 2;

        for(int l = i + j - 1; l >= 0; --l) {
            int m = l / 10;
            int n = l % 10;

            int x = drawContext.getScaledWindowWidth() / 2 - 91;
            int y = drawContext.getScaledWindowHeight() - 39;

            int o = x + n * 8;
            int p = y - m * lines;
            //int o = 10;
            //int p = -m * lines;
            //int p = 10;
            if (lastHealth + absorption <= 4) {
                p += random.nextInt(2);
            }

            if (l < i && l == regeneratingHeartIndex) {
                p -= 2;
            }

            drawHeart(drawContext, HudHeartType.CONTAINER, o, p, bl, blinking, false);
            int q = l * 2;
            boolean bl2 = l >= i;
            if (bl2) {
                int r = q - k;
                if (r < absorption) {
                    boolean bl3 = r + 1 == absorption;
                    drawHeart(drawContext, heartType == HudHeartType.WITHERED ? heartType : HudHeartType.ABSORBING, o, p, bl, false, bl3);
                }
            }

            boolean bl4;
            if (blinking && q < health) {
                bl4 = q + 1 == health;
                drawHeart(drawContext, heartType, o, p, bl, true, bl4);
            }
            if (q < lastHealth) {
                bl4 = q + 1 == lastHealth;
                drawHeart(drawContext, heartType, o, p, bl, false, bl4);
            }
        }

    }*/

    private static void drawHeart(class_332 context, HudHeartType type, int x, int y, boolean hardcore, boolean blinking, boolean half) {
        //RenderSystem.enableBlend();
//        context.drawGuiTexture(type.getTexture(hardcore, half, blinking), 50, 50, 9, 9);
        //RenderSystem.disableBlend();
    }

    public static void drawNumberHealthGUIIndicator(class_1309 livingEntity, Color textColor, int x, int y, boolean shadow, class_332 drawContext){
        String name = String.valueOf(livingEntity.method_5797() != null ? livingEntity.method_5797().method_54160() : livingEntity.method_5476().getString());
        drawContext.method_51433(class_310.method_1551().field_1772, name, x, y, textColor.getRGB(), shadow);
        drawContext.method_51433(class_310.method_1551().field_1772, RenderUtils.getHealthText(livingEntity), x, y+10, textColor.getRGB(), shadow);
    }

    enum HudHeartType {
        CONTAINER(class_2960.method_60656("hud/heart/container"), class_2960.method_60656("hud/heart/container_blinking"), class_2960.method_60656("hud/heart/container"), class_2960.method_60656("hud/heart/container_blinking"), class_2960.method_60656("hud/heart/container_hardcore"), class_2960.method_60656("hud/heart/container_hardcore_blinking"), class_2960.method_60656("hud/heart/container_hardcore"), class_2960.method_60656("hud/heart/container_hardcore_blinking")),
        NORMAL(class_2960.method_60656("hud/heart/full"), class_2960.method_60656("hud/heart/full_blinking"), class_2960.method_60656("hud/heart/half"), class_2960.method_60656("hud/heart/half_blinking"), class_2960.method_60656("hud/heart/hardcore_full"), class_2960.method_60656("hud/heart/hardcore_full_blinking"), class_2960.method_60656("hud/heart/hardcore_half"), class_2960.method_60656("hud/heart/hardcore_half_blinking")),
        POISONED(class_2960.method_60656("hud/heart/poisoned_full"), class_2960.method_60656("hud/heart/poisoned_full_blinking"), class_2960.method_60656("hud/heart/poisoned_half"), class_2960.method_60656("hud/heart/poisoned_half_blinking"), class_2960.method_60656("hud/heart/poisoned_hardcore_full"), class_2960.method_60656("hud/heart/poisoned_hardcore_full_blinking"), class_2960.method_60656("hud/heart/poisoned_hardcore_half"), class_2960.method_60656("hud/heart/poisoned_hardcore_half_blinking")),
        WITHERED(class_2960.method_60656("hud/heart/withered_full"), class_2960.method_60656("hud/heart/withered_full_blinking"), class_2960.method_60656("hud/heart/withered_half"), class_2960.method_60656("hud/heart/withered_half_blinking"), class_2960.method_60656("hud/heart/withered_hardcore_full"), class_2960.method_60656("hud/heart/withered_hardcore_full_blinking"), class_2960.method_60656("hud/heart/withered_hardcore_half"), class_2960.method_60656("hud/heart/withered_hardcore_half_blinking")),
        ABSORBING(class_2960.method_60656("hud/heart/absorbing_full"), class_2960.method_60656("hud/heart/absorbing_full_blinking"), class_2960.method_60656("hud/heart/absorbing_half"), class_2960.method_60656("hud/heart/absorbing_half_blinking"), class_2960.method_60656("hud/heart/absorbing_hardcore_full"), class_2960.method_60656("hud/heart/absorbing_hardcore_full_blinking"), class_2960.method_60656("hud/heart/absorbing_hardcore_half"), class_2960.method_60656("hud/heart/absorbing_hardcore_half_blinking")),
        FROZEN(class_2960.method_60656("hud/heart/frozen_full"), class_2960.method_60656("hud/heart/frozen_full_blinking"), class_2960.method_60656("hud/heart/frozen_half"), class_2960.method_60656("hud/heart/frozen_half_blinking"), class_2960.method_60656("hud/heart/frozen_hardcore_full"), class_2960.method_60656("hud/heart/frozen_hardcore_full_blinking"), class_2960.method_60656("hud/heart/frozen_hardcore_half"), class_2960.method_60656("hud/heart/frozen_hardcore_half_blinking"));

        private final class_2960 fullTexture;
        private final class_2960 fullBlinkingTexture;
        private final class_2960 halfTexture;
        private final class_2960 halfBlinkingTexture;
        private final class_2960 hardcoreFullTexture;
        private final class_2960 hardcoreFullBlinkingTexture;
        private final class_2960 hardcoreHalfTexture;
        private final class_2960 hardcoreHalfBlinkingTexture;

        HudHeartType(final class_2960 fullTexture, final class_2960 fullBlinkingTexture, final class_2960 halfTexture, final class_2960 halfBlinkingTexture, final class_2960 hardcoreFullTexture, final class_2960 hardcoreFullBlinkingTexture, final class_2960 hardcoreHalfTexture, final class_2960 hardcoreHalfBlinkingTexture) {
            this.fullTexture = fullTexture;
            this.fullBlinkingTexture = fullBlinkingTexture;
            this.halfTexture = halfTexture;
            this.halfBlinkingTexture = halfBlinkingTexture;
            this.hardcoreFullTexture = hardcoreFullTexture;
            this.hardcoreFullBlinkingTexture = hardcoreFullBlinkingTexture;
            this.hardcoreHalfTexture = hardcoreHalfTexture;
            this.hardcoreHalfBlinkingTexture = hardcoreHalfBlinkingTexture;
        }

        public class_2960 getTexture(boolean hardcore, boolean half, boolean blinking) {
            if (!hardcore) {
                if (half) {
                    return blinking ? this.halfBlinkingTexture : this.halfTexture;
                } else {
                    return blinking ? this.fullBlinkingTexture : this.fullTexture;
                }
            } else if (half) {
                return blinking ? this.hardcoreHalfBlinkingTexture : this.hardcoreHalfTexture;
            } else {
                return blinking ? this.hardcoreFullBlinkingTexture : this.hardcoreFullTexture;
            }
        }

        static HudHeartType fromEntityState(class_1309 livingEntity) {
            HudHeartType heartType;
            if (livingEntity.method_6059(class_1294.field_5899)) {
                heartType = POISONED;
            } else if (livingEntity.method_6059(class_1294.field_5920)) {
                heartType = WITHERED;
            } else if (livingEntity.method_32314()) {
                heartType = FROZEN;
            } else {
                heartType = NORMAL;
            }

            return heartType;
        }
    }

}
