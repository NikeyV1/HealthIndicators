package io.github.adytech99.healthindicators.mixin;

import io.github.adytech99.healthindicators.DamageDirectionIndicatorRenderer;
import io.github.adytech99.healthindicators.HealthIndicatorsCommon;
import io.github.adytech99.healthindicators.RenderTracker;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_1309.class, remap = false)
public class EntityDamageMixin {
    @Inject(method = "onDamaged(Lnet/minecraft/entity/damage/DamageSource;)V", at = @At("TAIL"))
    private void onEntityDamage(class_1282 damageSource, CallbackInfo callbackInfo) {
        RenderTracker.onDamage(damageSource, ((class_1309) (Object) this));

        if (damageSource.method_5529() instanceof class_1309 attacker && attacker != null && (Object) this == HealthIndicatorsCommon.client.field_1724) {
            DamageDirectionIndicatorRenderer.markDamageToPlayer(attacker);
        }
    }
}
