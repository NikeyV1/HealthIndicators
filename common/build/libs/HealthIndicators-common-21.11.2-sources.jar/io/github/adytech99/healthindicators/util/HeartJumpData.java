package io.github.adytech99.healthindicators.util;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_310;

public class HeartJumpData {
    private static final class_310 client = class_310.method_1551();

    private static boolean isHeartJumping = false;
    private static int whichHeartJumping = -1;

    public static int getWhichHeartJumping(class_1309 livingEntity) {
        return (int) (livingEntity.field_6012 % livingEntity.method_6063());
    }

    public static boolean isHeartJumping() {
        return isHeartJumping;
    }

    public static void tick(class_310 client){
        class_1657 player = client.field_1724;
        if(player == null) return;
        if(whichHeartJumping != -1){
            whichHeartJumping++;
            isHeartJumping = true;
            if(whichHeartJumping > player.method_6063()/2){
                whichHeartJumping = -1;
                isHeartJumping = false;
            }
        } else if (player.field_6012 % 16 == 0) {
            whichHeartJumping = 1;
            isHeartJumping = true;
        }
        else isHeartJumping = false;
        //client.player.sendMessage(Text.literal(String.valueOf(whichHeartJumping)), true);
    }
}
