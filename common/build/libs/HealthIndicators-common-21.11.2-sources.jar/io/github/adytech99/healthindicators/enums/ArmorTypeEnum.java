package io.github.adytech99.healthindicators.enums;

import net.minecraft.class_2960;

public enum ArmorTypeEnum {
    FULL("armor_full"),
    HALF("armor_half"),
    EMPTY("armor_empty");

    public final class_2960 icon;
    public final class_2960 vanillaIcon;

    ArmorTypeEnum(String armorIcon) {
        icon = class_2960.method_60655("minecraft", "textures/gui/sprites/hud/" + armorIcon + ".png");
        vanillaIcon = class_2960.method_60655("healthindicators", "textures/gui/armor/" + armorIcon + ".png");
    }
}