package io.github.adytech99.healthindicators.enums;

import dev.isxander.yacl3.api.NameableEnum;
import net.minecraft.class_2561;

public enum DamageReasonEnum implements NameableEnum {
    ANY("ANY"),
    SELF("SELF"),
    PLAYER("ANY PLAYER"),
    MOB("ANY MOB"),
    NATURE("NATURAL");

    private final String displayName;
    DamageReasonEnum(String displayName) {
        this.displayName = displayName;
    }
    @Override
    public class_2561 getDisplayName() {
        return class_2561.method_30163(displayName);
    }
}
