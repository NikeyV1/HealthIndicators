package io.github.adytech99.healthindicators;

import dev.architectury.event.events.client.ClientGuiEvent;
import io.github.adytech99.healthindicators.config.Config;
import io.github.adytech99.healthindicators.config.ModConfig;
import io.github.adytech99.healthindicators.util.ConfigUtils;
import io.github.adytech99.healthindicators.util.Util;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_8710;
import net.minecraft.class_9779;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class HealthIndicatorsCommon {
    public static final String MOD_ID = "healthindicators";
    public static class_310 client = class_310.method_1551();
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final class_304.class_11900 HEALTH_INDICATORS_CATEGORY = class_304.class_11900.method_74698(class_2960.method_60655(MOD_ID, "main"));

    public static final class_8710.class_9154<PingPayload> HANDSHAKE_CHANNEL =
            new class_8710.class_9154<>(class_2960.method_60655(MOD_ID, "handshake"));

    private static boolean changed = false;
    private static boolean openConfig = false;


    public static void init() {
        ModConfig.HANDLER.load();
        Config.load();
        ClientGuiEvent.RENDER_HUD.register(HealthIndicatorsCommon::onHudRender);
        client = class_310.method_1551();
        LOGGER.info("Never be heartless!");
    }

    public static void tick(){
        if(openConfig){
            class_437 configScreen = ModConfig.createScreen(client.field_1755);
            client.method_1507(configScreen);
            openConfig = false;
        }
        if(client == null || client.field_1687 == null){
            client = class_310.method_1551();
            return;
        }
        if(changed && client.field_1687 != null && client.field_1687.method_75260() % 200 == 0){
            ModConfig.HANDLER.save();
            changed = false;
        }
        RenderTracker.tick(client);
        DamageDirectionIndicatorRenderer.tick();
    }

    public static void onHudRender(class_332 drawContext1, class_9779 renderTickCounter1) {
        if(RenderTracker.getTrackedEntity() != null) HudRenderer.onHudRender(drawContext1, renderTickCounter1);
        if(ModConfig.HANDLER.instance().enable_damage_direction_indicators && client.method_1542()) DamageDirectionIndicatorRenderer.render(drawContext1, renderTickCounter1.method_60638());
    }

    public static void openConfig(){
        try {
            openConfig = client.field_1687 != null;
        } catch (NullPointerException e) {
            openConfig = false;
        }
    }

    public static void enableHeartsRendering(){
        Config.setHeartsRenderingEnabled(!Config.getHeartsRenderingEnabled());
        if (client != null && client.field_1724 != null) {
            class_124 formatting;
            if(ModConfig.HANDLER.instance().colored_messages) formatting = Config.getHeartsRenderingEnabled() ? class_124.field_1060 : class_124.field_1061;
            else formatting = class_124.field_1068;
            ConfigUtils.sendMessage(client.field_1724, class_2561.method_43470((Config.getHeartsRenderingEnabled() ? "Enabled" : "Disabled") + " Health Indicators").method_27692(formatting));
        }
    }

    public static void enableArmorRendering(){
        Config.setArmorRenderingEnabled(!Config.getArmorRenderingEnabled());
        if (client != null && client.field_1724 != null) {
            class_124 formatting;
            if(ModConfig.HANDLER.instance().colored_messages) formatting = Config.getArmorRenderingEnabled() ? class_124.field_1060 : class_124.field_1061;
            else formatting = class_124.field_1068;
            ConfigUtils.sendMessage(client.field_1724, class_2561.method_43470((Config.getArmorRenderingEnabled() ? "Enabled" : "Disabled") + " Armor Indicators").method_27692(formatting));
        }
    }

    public static void increaseOffset(){
        ModConfig.HANDLER.instance().display_offset = Math.clamp(ModConfig.HANDLER.instance().display_offset + ModConfig.HANDLER.instance().offset_step_size, -5.0, 5.0);
        changed = true;
        if (client != null && client.field_1724 != null) {
            ConfigUtils.sendMessage(client.field_1724, class_2561.method_43470("Set heart offset to " + Util.truncate(ModConfig.HANDLER.instance().display_offset,2)));
        }
    }
    public static void decreaseOffset(){
        ModConfig.HANDLER.instance().display_offset = Math.clamp(
                ModConfig.HANDLER.instance().display_offset - ModConfig.HANDLER.instance().offset_step_size,
                -5.0, 5.0);
        changed = true;
        if (client != null && client.field_1724 != null) {
            ConfigUtils.sendMessage(client.field_1724, class_2561.method_43470("Set heart offset to " + Util.truncate(ModConfig.HANDLER.instance().display_offset,2)));
        }
    }

    public static void overrideFilters(){
        Config.setOverrideAllFiltersEnabled(true);
        if (client != null && client.field_1724 != null) {
            ConfigUtils.sendOverlayMessage(client.field_1724, class_2561.method_43470( " Config Criteria " + (Config.getOverrideAllFiltersEnabled() ? "Temporarily Overridden" : "Re-implemented")));
        }
    }

    public static void disableOverrideFilters(){
        Config.setOverrideAllFiltersEnabled(false);
        client.field_1705.method_1758(class_2561.method_43470(""), false);
    }

    public static void openConfigScreen(){
        openConfig();
    }
}