package io.github.adytech99.healthindicators;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

public record ServerPermissionPayload(boolean allowInvisiblePlayers) implements class_8710 {

    public static final class_8710.class_9154<ServerPermissionPayload> ID =
            new class_8710.class_9154<>(class_2960.method_60655(HealthIndicatorsCommon.MOD_ID, "server_permissions"));

    public static final class_9139<class_2540, ServerPermissionPayload> CODEC =
            class_9139.method_56438(
                    (value, buf) -> buf.method_52964(value.allowInvisiblePlayers),
                    buf -> new ServerPermissionPayload(buf.readBoolean())
            );

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}