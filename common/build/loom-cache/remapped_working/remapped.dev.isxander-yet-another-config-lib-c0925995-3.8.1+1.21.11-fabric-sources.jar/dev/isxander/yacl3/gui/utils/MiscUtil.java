package dev.isxander.yacl3.gui.utils;

import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class MiscUtil {
    public static <T> T getFromRegistry(Registry<T> registry, Identifier identifier) {
        //? if >=1.21.2 {
        return registry.get(identifier);
        //?} else {
        /*return registry.get(identifier);
        *///?}
    }
}
