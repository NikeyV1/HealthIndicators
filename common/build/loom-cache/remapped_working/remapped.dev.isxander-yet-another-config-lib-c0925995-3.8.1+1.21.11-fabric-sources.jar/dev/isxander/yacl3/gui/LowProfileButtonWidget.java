package dev.isxander.yacl3.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;

public class LowProfileButtonWidget extends /*? if >=1.21.11 {*/ButtonWidget.Text/*?} else {*//*Button*//*?}*/ {
    public LowProfileButtonWidget(int x, int y, int width, int height, net.minecraft.text.Text message, PressAction onPress) {
        super(x, y, width, height, message, onPress, DEFAULT_NARRATION_SUPPLIER);
    }

    public LowProfileButtonWidget(int x, int y, int width, int height, net.minecraft.text.Text message, PressAction onPress, Tooltip tooltip) {
        this(x, y, width, height, message, onPress);
        setTooltip(tooltip);
    }

    //? if >=1.21.11 {
    @Override
    protected void drawIcon(DrawContext guiGraphics, int i, int j, float f) {
        if (isSelected() && isInteractable()) {
            this.drawButton(guiGraphics);
        }
        this.drawLabel(guiGraphics.getHoverListener(this, DrawContext.HoverType.NONE));
    }
    //?} else {
    /*@Override
    public void renderWidget(GuiGraphics graphics, int mouseX, int mouseY, float deltaTicks) {
        if (!isHoveredOrFocused() || !active) {
            int j = this.active ? 0xFFFFFFFF : 0xFFA0A0A0;
            this.renderString(graphics, Minecraft.getInstance().font, j);
        } else {
            super.renderWidget(graphics, mouseX, mouseY, deltaTicks);
        }
    }
    *///?}
}
