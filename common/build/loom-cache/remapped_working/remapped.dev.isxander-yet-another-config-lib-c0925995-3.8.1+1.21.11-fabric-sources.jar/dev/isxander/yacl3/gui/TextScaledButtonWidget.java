package dev.isxander.yacl3.gui;

import dev.isxander.yacl3.gui.utils.GuiUtils;
import net.minecraft.client.font.DrawnTextConsumer;
import net.minecraft.client.gui.screen.Screen;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3x2f;
import org.joml.Matrix4f;

public class TextScaledButtonWidget extends TooltipButtonWidget {
    public float textScale;

    public TextScaledButtonWidget(Screen screen, int x, int y, int width, int height, float textScale, net.minecraft.text.Text message, net.minecraft.text.Text tooltip, PressAction onPress) {
        super(screen, x, y, width, height, message, tooltip, onPress);
        this.textScale = textScale;
    }

    public TextScaledButtonWidget(Screen screen, int x, int y, int width, int height, float textScale, net.minecraft.text.Text message, PressAction onPress) {
        this(screen, x, y, width, height, textScale, message, null, onPress);
    }

    // FIXME: i cannot figure out how to compensate a scale with a translation so for now the reset button is small fuck you
    //? if >=1.21.11 {
    @Override
    protected void drawLabel(@NotNull DrawnTextConsumer activeTextCollector) {
        super.drawLabel(activeTextCollector);
    }
    //?} else {
    /*@Override
    public void renderString(GuiGraphics graphics, Font textRenderer, int color) {
        Font font = Minecraft.getInstance().font;

        GuiUtils.pushPose(graphics);
        GuiUtils.translate2D(graphics, ((this.getX() + this.width / 2f) - font.width(getMessage()) * textScale / 2), (float)this.getY() + (this.height - 8 * textScale) / 2f / textScale);
        GuiUtils.scale2D(graphics, textScale, textScale);
        graphics.drawString(font, getMessage(), 0, 0, color | Mth.ceil(this.alpha * 255.0F) << 24, true);
        GuiUtils.popPose(graphics);
    }
    *///?}
}
