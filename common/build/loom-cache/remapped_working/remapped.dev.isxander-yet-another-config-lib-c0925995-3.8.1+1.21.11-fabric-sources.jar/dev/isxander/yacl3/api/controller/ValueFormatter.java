package dev.isxander.yacl3.api.controller;

import net.minecraft.text.Text;

public interface ValueFormatter<T> {
    Text format(T value);
}
