package dev.isxander.yacl3.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.ParentElement;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.navigation.GuiNavigation;
import net.minecraft.client.gui.navigation.NavigationAxis;
import net.minecraft.client.gui.navigation.NavigationDirection;
import net.minecraft.client.gui.widget.TabNavigationWidget;

@Mixin(ParentElement.class)
public interface ContainerEventHandlerMixin {
     // This mixin is used to prevent the tab bar from being focused when navigating left or right
     // through the YACL options screen. This can also apply to vanilla as navigating left or right
     // should never result in focusing the always-at-the-top tab bar.
     // Without this, navigating right from the option list focuses the tab bar, not the action buttons/description.
    @Redirect(method = {"nextFocusPathVaguelyInDirection", "nextFocusPathInDirection"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/events/ContainerEventHandler;children()Ljava/util/List;"))
    default List<?> modifyFocusCandidates(ParentElement instance, ScreenRect screenArea, NavigationDirection direction, @Nullable Element focused, GuiNavigation event) {
        if (direction.getAxis() == NavigationAxis.HORIZONTAL)
            return instance.children().stream().filter(child -> !(child instanceof TabNavigationWidget)).toList();
        return instance.children();
    }
}
/*?} else {*/
/*@Mixin(ContainerEventHandler.class)
public class ContainerEventHandlerMixin {

}
*//*?}*/
