package dev.isxander.yacl3.gui.render;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;

//?}

public interface YACLGuiElementRenderState /*? if >=1.21.6 {*/extends SimpleGuiElementRenderState /*?}*/ {

    BaseRenderState baseState();

    //? if >=1.21.9 {
    @Override
    default void setupVertices(VertexConsumer vertexConsumer) {
        this.buildVertices(vertexConsumer, 0);
    }

    // purely to ease development, we backport this method from <1.21.9 and have a placeholder Z
    void buildVertices(VertexConsumer vertexConsumer, float z);
    //?}

    //? if >=1.21.6 {
    @Override
    default @NotNull RenderPipeline pipeline() {
        return baseState().pipeline();
    }

    @Override
    default @NotNull TextureSetup textureSetup() {
        return baseState().textureSetup();
    }

    @Override
    default @Nullable ScreenRect scissorArea() {
        return baseState().scissorArea();
    }

    @Override
    default @Nullable ScreenRect bounds() {
        return baseState().bounds();
    }
    //?} else {
    /*void buildVertices(VertexConsumer vertexConsumer, float z);
    *///?}

    default VertexConsumer add2DVertex(
            VertexConsumer vertexConsumer,
            float x, float y, float z
    ) {
        //? if >=1.21.6 {
        return vertexConsumer.vertex(this.baseState().pose(), x, y /*? if <1.21.9 >>*/ /*,z*/ );
        //?} else {
        /*return vertexConsumer.addVertex(this.baseState().pose(), x, y, z);
        *///?}
    }

    default void submit(DrawContext graphics) {
        //? if >=1.21.6 {
        GuiRenderStateSink.submit(graphics, this);
        //?} else {
        /*// TODO: don't drawSpecial as it finishes the batch
        VertexConsumer vertexConsumer = GuiRenderStateSink.bufferSource(graphics).getBuffer(baseState().renderType());
        buildVertices(vertexConsumer, 0);
        *///?}
    }


}
