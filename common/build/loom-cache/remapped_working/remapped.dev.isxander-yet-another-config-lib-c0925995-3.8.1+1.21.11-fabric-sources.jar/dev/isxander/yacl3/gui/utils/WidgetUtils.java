package dev.isxander.yacl3.gui.utils;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.Element;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.input.MouseInput;

public final class WidgetUtils {

    public static boolean mouseClicked(Element l, double mouseX, double mouseY, int button) {
        //? if >=1.21.9 {
        return l.mouseClicked(new Click(mouseX, mouseY, new MouseInput(button, 0)), false);
        //?} else {
        /*return l.mouseClicked(mouseX, mouseY, button);
        *///?}
    }

    public static boolean keyPressed(Element l, int keyCode, int scanCode, int modifiers) {
        //? if >=1.21.9 {
        return l.keyPressed(new KeyInput(keyCode, scanCode, modifiers));
        //?} else {
        /*return l.keyPressed(keyCode, scanCode, modifiers);
        *///?}
    }

    public static boolean charTyped(Element l, char codePoint, int modifiers) {
        //? if >=1.21.9 {
        return l.charTyped(new CharInput(codePoint, modifiers));
        //?} else {
        /*return l.charTyped(codePoint, modifiers);
        *///?}
    }

    public static boolean mouseDragged(Element l, double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        //? if >=1.21.9 {
        return l.mouseDragged(new Click(mouseX, mouseY, new MouseInput(button, 0)), deltaX, deltaY);
        //?} else {
        /*return l.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        *///?}
    }

    private WidgetUtils() {
    }
}
