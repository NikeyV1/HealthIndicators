package dev.isxander.yacl3.gui;

import dev.isxander.yacl3.api.OptionDescription;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public record DescriptionWithName(Text name, OptionDescription description) {
    public static DescriptionWithName of(Text name, OptionDescription description) {
        return new DescriptionWithName(name.copy().formatted(Formatting.BOLD), description);
    }
}
