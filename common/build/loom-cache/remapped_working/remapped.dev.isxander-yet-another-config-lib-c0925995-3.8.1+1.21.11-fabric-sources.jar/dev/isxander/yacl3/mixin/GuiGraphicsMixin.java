package dev.isxander.yacl3.mixin;

import dev.isxander.yacl3.gui.render.GuiRenderStateSink;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.GuiRenderState;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(DrawContext.class)
public class GuiGraphicsMixin implements GuiRenderStateSink {

    //? if >=1.21.6 {
    @Shadow @Final private GuiRenderState guiRenderState;

    @Override
    public void yacl$submit(SimpleGuiElementRenderState renderState) {
        this.guiRenderState.addSimpleElement(renderState);
    }


    @Shadow @Final private DrawContext.ScissorStack scissorStack;

    @Override
    public ScreenRect yacl$peekScissorStack() {
        return this.scissorStack.method_70863();
    }
    //?} else {
    /*@Shadow
    @Final
    private MultiBufferSource.BufferSource bufferSource;

    @Override
    public MultiBufferSource yacl$bufferSource() {
        return this.bufferSource;
    }
    *///?}
}
