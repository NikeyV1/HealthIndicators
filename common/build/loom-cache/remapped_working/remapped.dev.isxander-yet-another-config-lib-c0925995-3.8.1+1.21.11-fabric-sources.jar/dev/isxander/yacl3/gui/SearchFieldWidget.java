package dev.isxander.yacl3.gui;

import java.util.function.Consumer;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class SearchFieldWidget extends TextFieldWidget {
    private Text emptyText;
    private final YACLScreen yaclScreen;
    private final TextRenderer font;
    private final Consumer<String> updateConsumer;

    private boolean isEmpty = true;

    public SearchFieldWidget(YACLScreen yaclScreen, TextRenderer font, int x, int y, int width, int height, Text text, Text emptyText, Consumer<String> updateConsumer) {
        super(font, x, y, width, height, text);
        setChangedListener(this::update);
        setTextPredicate(string -> !string.endsWith("  ") && !string.startsWith(" "));
        this.yaclScreen = yaclScreen;
        this.font = font;
        this.emptyText = emptyText;
        this.updateConsumer = updateConsumer;
    }

    @Override
    public void renderWidget(DrawContext graphics, int mouseX, int mouseY, float delta) {
        super.renderWidget(graphics, mouseX, mouseY, delta);
        if (isVisible() && isEmpty()) {
            graphics.drawText(font, emptyText, getX() + 4, this.getY() + (this.height - 8) / 2, 0x707070, true);
        }
    }

    private void update(String query) {
        boolean wasEmpty = isEmpty;
        isEmpty = query.isEmpty();

        if (isEmpty && wasEmpty)
            return;

        updateConsumer.accept(query);
    }

    public String getQuery() {
        return getText().toLowerCase();
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public Text getEmptyText() {
        return emptyText;
    }

    public void setEmptyText(Text emptyText) {
        this.emptyText = emptyText;
    }
}
