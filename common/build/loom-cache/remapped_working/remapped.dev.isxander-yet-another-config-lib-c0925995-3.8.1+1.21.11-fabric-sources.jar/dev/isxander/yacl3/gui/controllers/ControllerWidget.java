package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.AbstractWidget;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.utils.GuiUtils;
import net.minecraft.client.font.MultilineText;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.navigation.GuiNavigation;
import net.minecraft.client.gui.navigation.GuiNavigationPath;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.screen.narration.NarrationPart;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.Nullable;

public abstract class ControllerWidget<T extends Controller<?>> extends AbstractWidget {
    protected final T control;
    protected MultilineText wrappedTooltip;
    protected final YACLScreen screen;

    protected boolean focused = false;
    protected boolean hovered = false;

    protected final Text modifiedOptionName;
    protected final String optionNameString;

    public ControllerWidget(T control, YACLScreen screen, Dimension<Integer> dim) {
        super(dim);
        this.control = control;
        this.screen = screen;
        control.option().addListener((opt, pending) -> updateTooltip());
        updateTooltip();
        this.modifiedOptionName = control.option().name().copy().formatted(Formatting.ITALIC);
        this.optionNameString = control.option().name().getString().toLowerCase();
    }

    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        hovered = isMouseOver(mouseX, mouseY);

        Text name = control.option().changed() ? modifiedOptionName : control.option().name();
        Text shortenedName = Text.literal(GuiUtils.shortenString(name.getString(), textRenderer, getDimension().width() - getControlWidth() - getXPadding() - 7, "...")).setStyle(name.getStyle());

        drawButtonRect(graphics, getDimension().x(), getDimension().y(), getDimension().xLimit(), getDimension().yLimit(), (hovered && isAvailable()) || focused, isAvailable());
        graphics.drawText(textRenderer, shortenedName, getDimension().x() + getXPadding(), getTextY(), getValueColor(), true);


        drawValueText(graphics, mouseX, mouseY, delta);
        if (isHovered()) {
            drawHoveredControl(graphics, mouseX, mouseY, delta);
        }
    }

    protected void drawHoveredControl(DrawContext graphics, int mouseX, int mouseY, float delta) {

    }

    protected void drawValueText(DrawContext graphics, int mouseX, int mouseY, float delta) {
        Text valueText = getValueText();
        graphics.drawText(textRenderer, valueText, getDimension().xLimit() - textRenderer.getWidth(valueText) - getXPadding(), getTextY(), getValueColor(), true);
    }

    private void updateTooltip() {
        this.wrappedTooltip = MultilineText.create(textRenderer, control.option().tooltip(), screen.width / 3 * 2 - 10);
    }

    protected int getControlWidth() {
        return isHovered() ? getHoveredControlWidth() : getUnhoveredControlWidth();
    }

    public boolean isHovered() {
        return isAvailable() && (hovered || focused);
    }

    protected abstract int getHoveredControlWidth();

    protected int getUnhoveredControlWidth() {
        return textRenderer.getWidth(getValueText());
    }

    protected int getXPadding() {
        return 5;
    }

    protected int getYPadding() {
        return 2;
    }

    protected Text getValueText() {
        return control.formatValue();
    }

    protected boolean isAvailable() {
        return control.option().available();
    }

    protected int getValueColor() {
        return isAvailable() ? -1 : inactiveColor;
    }

    @Override
    public boolean canReset() {
        return true;
    }

    protected int getTextY() {
        return (int)(getDimension().y() + getDimension().height() / 2f - textRenderer.fontHeight / 2f);
    }

    @Nullable
    @Override
    public GuiNavigationPath getNavigationPath(GuiNavigation focusNavigationEvent) {
        return !this.isFocused() ? GuiNavigationPath.of(this) : null;
    }

    @Override
    public boolean isFocused() {
        return focused;
    }

    @Override
    public void setFocused(boolean focused) {
        this.focused = focused;
    }

    @Override
    public void unfocus() {
        this.focused = false;
    }

    @Override
    public boolean matchesSearch(String query) {
        return optionNameString.contains(query.toLowerCase());
    }

    @Override
    public SelectionType getType() {
        return focused ? SelectionType.FOCUSED : isHovered() ? SelectionType.HOVERED : SelectionType.NONE;
    }

    @Override
    public void appendNarrations(NarrationMessageBuilder builder) {
        builder.put(NarrationPart.TITLE, control.option().name());
        builder.put(NarrationPart.HINT, control.option().tooltip());
    }
}
