/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.networking;

import dev.architectury.extensions.network.EntitySpawnExtension;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.Packet;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.EntityTrackerEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

/**
 * @see net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket
 */
public class SpawnEntityPacket {
    static final Identifier PACKET_ID = Identifier.of("architectury", "spawn_entity_packet");
    static final CustomPayload.Id<PacketPayload> PACKET_TYPE = new CustomPayload.Id<>(PACKET_ID);
    static final PacketCodec<RegistryByteBuf, PacketPayload> PACKET_CODEC = CustomPayload.codecOf(PacketPayload::write, PacketPayload::new);
    
    public static Packet<ClientPlayPacketListener> create(Entity entity, EntityTrackerEntry serverEntity) {
        if (entity.getEntityWorld().isClient()) {
            throw new IllegalStateException("SpawnPacketUtil.create called on the logical client!");
        }
        return (Packet<ClientPlayPacketListener>) NetworkManager.toPacket(NetworkManager.s2c(), new PacketPayload(entity, serverEntity), entity.getRegistryManager());
    }
    
    public static void register() {
        NetworkManager.registerS2CPayloadType(PACKET_TYPE, PACKET_CODEC);
    }
    
    record PacketPayload(EntityType<?> entityType, UUID uuid, int id, double x, double y, double z, float xRot,
                                 float yRot,
                                 float yHeadRot,
                                 double deltaX, double deltaY, double deltaZ,
                                 byte[] data) implements CustomPayload {
        public PacketPayload(RegistryByteBuf buf) {
            this(PacketCodecs.registryValue(RegistryKeys.ENTITY_TYPE).decode(buf), buf.readUuid(), buf.readVarInt(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readDouble(), buf.readDouble(), buf.readDouble(),
                    buf.readByteArray());
        }
        
        public PacketPayload(Entity entity, EntityTrackerEntry serverEntity) {
            this(entity.getType(), entity.getUuid(), entity.getId(), serverEntity.getPos().getX(),
                    serverEntity.getPos().getY(), serverEntity.getPos().getZ(), serverEntity.getPitch(),
                    serverEntity.getYaw(), serverEntity.getHeadYaw(), serverEntity.getVelocity().x,
                    serverEntity.getVelocity().y, serverEntity.getVelocity().z, saveExtra(entity));
        }
        
        public PacketPayload(Entity entity, BlockPos pos) {
            this(entity.getType(), entity.getUuid(), entity.getId(), pos.getX(),
                    pos.getY(), pos.getZ(), entity.getPitch(), entity.getYaw(), entity.getHeadYaw(),
                    entity.getVelocity().x, entity.getVelocity().y, entity.getVelocity().z, saveExtra(entity));
        }
        
        private static byte[] saveExtra(Entity entity) {
            PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
            try {
                if (entity instanceof EntitySpawnExtension ext) {
                    ext.saveAdditionalSpawnData(buf);
                }
                return ByteBufUtil.getBytes(buf);
            } finally {
                buf.release();
            }
        }
        
        public void write(RegistryByteBuf buf) {
            PacketCodecs.registryValue(RegistryKeys.ENTITY_TYPE).encode(buf, entityType);
            buf.writeUuid(uuid);
            buf.writeVarInt(id);
            buf.writeDouble(x);
            buf.writeDouble(y);
            buf.writeDouble(z);
            buf.writeFloat(xRot);
            buf.writeFloat(yRot);
            buf.writeFloat(yHeadRot);
            buf.writeDouble(deltaX);
            buf.writeDouble(deltaY);
            buf.writeDouble(deltaZ);
            buf.writeByteArray(data);
        }
        
        @Override
        public Id<? extends CustomPayload> getId() {
            return PACKET_TYPE;
        }
    }
}
