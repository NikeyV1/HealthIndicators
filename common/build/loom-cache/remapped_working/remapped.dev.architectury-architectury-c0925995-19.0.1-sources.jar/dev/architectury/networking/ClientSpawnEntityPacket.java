/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.networking;

import dev.architectury.extensions.network.EntitySpawnExtension;
import io.netty.buffer.Unpooled;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.SpawnReason;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.util.math.Vec3d;

public class ClientSpawnEntityPacket {
    public static void register() {
        NetworkManager.registerReceiver(NetworkManager.s2c(), SpawnEntityPacket.PACKET_TYPE, SpawnEntityPacket.PACKET_CODEC, ClientSpawnEntityPacket::receive);
    }
    
    private static void receive(SpawnEntityPacket.PacketPayload payload, NetworkManager.PacketContext context) {
        context.queue(() -> {
            if (MinecraftClient.getInstance().world == null) {
                throw new IllegalStateException("Client world is null!");
            }
            var entity = payload.entityType().create(MinecraftClient.getInstance().world, SpawnReason.LOAD);
            if (entity == null) {
                throw new IllegalStateException("Created entity is null!");
            }
            entity.setUuid(payload.uuid());
            entity.setId(payload.id());
            entity.updateTrackedPosition(payload.x(), payload.y(), payload.z());
            entity.refreshPositionAndAngles(payload.x(), payload.y(), payload.z(), payload.xRot(), payload.yRot());
            entity.setHeadYaw(payload.yHeadRot());
            entity.setBodyYaw(payload.yHeadRot());
            if (entity instanceof EntitySpawnExtension ext) {
                RegistryByteBuf buf = new RegistryByteBuf(Unpooled.wrappedBuffer(payload.data()), context.registryAccess());
                ext.loadAdditionalSpawnData(buf);
                buf.release();
            }
            MinecraftClient.getInstance().world.addEntity(entity);
            entity.setVelocityClient(new Vec3d(payload.deltaX(), payload.deltaY(), payload.deltaZ()));
        });
    }
}
