/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.impl;

import com.google.common.base.Suppliers;
import dev.architectury.networking.NetworkManager;
import dev.architectury.networking.transformers.PacketSink;
import dev.architectury.networking.transformers.PacketTransformer;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import org.jetbrains.annotations.ApiStatus;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.network.packet.Packet;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.util.Identifier;

@ApiStatus.Internal
public class NetworkAggregator {
    public static final Supplier<Adaptor> ADAPTOR = Suppliers.memoize(() -> {
        try {
            Method adaptor = NetworkManager.class.getDeclaredMethod("getAdaptor");
            adaptor.setAccessible(true);
            return (Adaptor) adaptor.invoke(null);
        } catch (Throwable throwable) {
            throw new RuntimeException(throwable);
        }
    });
    public static final Map<Identifier, CustomPayload.Id<BufCustomPacketPayload>> C2S_TYPE = new HashMap<>();
    public static final Map<Identifier, CustomPayload.Id<BufCustomPacketPayload>> S2C_TYPE = new HashMap<>();
    public static final Map<Identifier, NetworkManager.NetworkReceiver<?>> C2S_RECEIVER = new HashMap<>();
    public static final Map<Identifier, NetworkManager.NetworkReceiver<?>> S2C_RECEIVER = new HashMap<>();
    public static final Map<Identifier, PacketCodec<ByteBuf, ?>> C2S_CODECS = new HashMap<>();
    public static final Map<Identifier, PacketCodec<ByteBuf, ?>> S2C_CODECS = new HashMap<>();
    public static final Map<Identifier, PacketTransformer> C2S_TRANSFORMERS = new HashMap<>();
    public static final Map<Identifier, PacketTransformer> S2C_TRANSFORMERS = new HashMap<>();
    
    public static void registerReceiver(NetworkManager.Side side, Identifier id, List<PacketTransformer> packetTransformers, NetworkManager.NetworkReceiver<RegistryByteBuf> receiver) {
        CustomPayload.Id<BufCustomPacketPayload> type = new CustomPayload.Id<>(id);
        if (side == NetworkManager.Side.C2S) {
            C2S_TYPE.put(id, type);
            registerC2SReceiver(type, BufCustomPacketPayload.streamCodec(type), packetTransformers, (value, context) -> {
                RegistryByteBuf buf = new RegistryByteBuf(Unpooled.wrappedBuffer(value.payload()), context.registryAccess());
                receiver.receive(buf, context);
                buf.release();
            });
        } else if (side == NetworkManager.Side.S2C) {
            S2C_TYPE.put(id, type);
            registerS2CReceiver(type, BufCustomPacketPayload.streamCodec(type), packetTransformers, (value, context) -> {
                RegistryByteBuf buf = new RegistryByteBuf(Unpooled.wrappedBuffer(value.payload()), context.registryAccess());
                receiver.receive(buf, context);
                buf.release();
            });
        }
    }
    
    public static <T extends CustomPayload> void registerReceiver(NetworkManager.Side side, CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, List<PacketTransformer> packetTransformers, NetworkManager.NetworkReceiver<T> receiver) {
        Objects.requireNonNull(type, "Cannot register receiver with a null type!");
        packetTransformers = Objects.requireNonNullElse(packetTransformers, List.of());
        Objects.requireNonNull(receiver, "Cannot register a null receiver!");
        if (side == NetworkManager.Side.C2S) {
            registerC2SReceiver(type, codec, packetTransformers, receiver);
        } else if (side == NetworkManager.Side.S2C) {
            registerS2CReceiver(type, codec, packetTransformers, receiver);
        }
    }
    
    private static <T extends CustomPayload> void registerC2SReceiver(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, List<PacketTransformer> packetTransformers, NetworkManager.NetworkReceiver<T> receiver) {
        PacketTransformer transformer = PacketTransformer.concat(packetTransformers);
        C2S_RECEIVER.put(type.id(), receiver);
        C2S_CODECS.put(type.id(), (PacketCodec<ByteBuf, ?>) codec);
        C2S_TRANSFORMERS.put(type.id(), transformer);
        ADAPTOR.get().registerC2S((CustomPayload.Id<BufCustomPacketPayload>) type, BufCustomPacketPayload.streamCodec((CustomPayload.Id<BufCustomPacketPayload>) type), (payload, context) -> {
            RegistryByteBuf buf = new RegistryByteBuf(Unpooled.wrappedBuffer(payload.payload()), context.registryAccess());
            transformer.inbound(NetworkManager.Side.C2S, type.id(), buf, context, (side, id1, buf1) -> {
                NetworkManager.NetworkReceiver<T> networkReceiver = (NetworkManager.NetworkReceiver<T>) (side == NetworkManager.Side.C2S ? C2S_RECEIVER.get(id1) : S2C_RECEIVER.get(id1));
                if (networkReceiver == null) {
                    throw new IllegalArgumentException("Network Receiver not found! " + id1);
                }
                T actualPayload = codec.decode(buf1);
                networkReceiver.receive(actualPayload, context);
            });
            buf.release();
        });
    }
    
    private static <T extends CustomPayload> void registerS2CReceiver(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, List<PacketTransformer> packetTransformers, NetworkManager.NetworkReceiver<T> receiver) {
        PacketTransformer transformer = PacketTransformer.concat(packetTransformers);
        S2C_RECEIVER.put(type.id(), receiver);
        S2C_CODECS.put(type.id(), (PacketCodec<ByteBuf, ?>) codec);
        S2C_TRANSFORMERS.put(type.id(), transformer);
        ADAPTOR.get().registerS2C((CustomPayload.Id<BufCustomPacketPayload>) type, BufCustomPacketPayload.streamCodec((CustomPayload.Id<BufCustomPacketPayload>) type), (payload, context) -> {
            RegistryByteBuf buf = new RegistryByteBuf(Unpooled.wrappedBuffer(payload.payload()), context.registryAccess());
            transformer.inbound(NetworkManager.Side.S2C, type.id(), buf, context, (side, id1, buf1) -> {
                NetworkManager.NetworkReceiver<T> networkReceiver = (NetworkManager.NetworkReceiver<T>) (side == NetworkManager.Side.C2S ? C2S_RECEIVER.get(id1) : S2C_RECEIVER.get(id1));
                if (networkReceiver == null) {
                    throw new IllegalArgumentException("Network Receiver not found! " + id1);
                }
                T actualPayload = codec.decode(buf1);
                networkReceiver.receive(actualPayload, context);
            });
            buf.release();
        });
    }
    
    public static void collectPackets(PacketSink sink, NetworkManager.Side side, Identifier id, RegistryByteBuf buf) {
        if (side == NetworkManager.Side.C2S) {
            collectPackets(sink, side, new BufCustomPacketPayload(C2S_TYPE.get(id), ByteBufUtil.getBytes(buf)), buf.getRegistryManager());
        } else {
            collectPackets(sink, side, new BufCustomPacketPayload(S2C_TYPE.get(id), ByteBufUtil.getBytes(buf)), buf.getRegistryManager());
        }
    }
    
    public static <T extends CustomPayload> void collectPackets(PacketSink sink, NetworkManager.Side side, T payload, DynamicRegistryManager access) {
        CustomPayload.Id<T> type = (CustomPayload.Id<T>) payload.getId();
        PacketTransformer transformer = side == NetworkManager.Side.C2S ? C2S_TRANSFORMERS.get(type.id()) : S2C_TRANSFORMERS.get(type.id());
        PacketCodec<ByteBuf, T> codec = (PacketCodec<ByteBuf, T>) (side == NetworkManager.Side.C2S ? C2S_CODECS.get(type.id()) : S2C_CODECS.get(type.id()));
        RegistryByteBuf buf = new RegistryByteBuf(Unpooled.buffer(), access);
        codec.encode(buf, payload);
        
        if (transformer != null) {
            transformer.outbound(side, type.id(), buf, (side1, id1, buf1) -> {
                if (side == NetworkManager.Side.C2S) {
                    CustomPayload.Id<BufCustomPacketPayload> type1 = C2S_TYPE.getOrDefault(id1, (CustomPayload.Id<BufCustomPacketPayload>) type);
                    sink.accept(toPacket(side1, new BufCustomPacketPayload(type1, ByteBufUtil.getBytes(buf1))));
                } else if (side == NetworkManager.Side.S2C) {
                    CustomPayload.Id<BufCustomPacketPayload> type1 = S2C_TYPE.getOrDefault(id1, (CustomPayload.Id<BufCustomPacketPayload>) type);
                    sink.accept(toPacket(side1, new BufCustomPacketPayload(type1, ByteBufUtil.getBytes(buf1))));
                }
            });
        } else {
            sink.accept(toPacket(side, new BufCustomPacketPayload((CustomPayload.Id<BufCustomPacketPayload>) type, ByteBufUtil.getBytes(buf))));
        }
        buf.release();
    }
    
    public static <T extends CustomPayload> Packet<?> toPacket(NetworkManager.Side side, T payload) {
        if (side == NetworkManager.Side.C2S) {
            return ADAPTOR.get().toC2SPacket(payload);
        } else if (side == NetworkManager.Side.S2C) {
            return ADAPTOR.get().toS2CPacket(payload);
        }
        
        throw new IllegalArgumentException("Invalid side: " + side);
    }
    
    public static void registerS2CType(Identifier id, List<PacketTransformer> packetTransformers) {
        CustomPayload.Id<BufCustomPacketPayload> type = new CustomPayload.Id<>(id);
        S2C_TYPE.put(id, type);
        registerS2CType(type, BufCustomPacketPayload.streamCodec(type), packetTransformers);
    }
    
    public static <T extends CustomPayload> void registerS2CType(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, List<PacketTransformer> packetTransformers) {
        Objects.requireNonNull(type, "Cannot register a null type!");
        packetTransformers = Objects.requireNonNullElse(packetTransformers, List.of());
        S2C_CODECS.put(type.id(), (PacketCodec<ByteBuf, ?>) codec);
        S2C_TRANSFORMERS.put(type.id(), PacketTransformer.concat(packetTransformers));
        ADAPTOR.get().registerS2CType((CustomPayload.Id<BufCustomPacketPayload>) type, BufCustomPacketPayload.streamCodec((CustomPayload.Id<BufCustomPacketPayload>) type));
    }
    
    public interface Adaptor {
        <T extends CustomPayload> void registerC2S(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, NetworkManager.NetworkReceiver<T> receiver);
        
        <T extends CustomPayload> void registerS2C(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec, NetworkManager.NetworkReceiver<T> receiver);
        
        <T extends CustomPayload> Packet<?> toC2SPacket(T payload);
        
        <T extends CustomPayload> Packet<?> toS2CPacket(T payload);
        
        <T extends CustomPayload> void registerS2CType(CustomPayload.Id<T> type, PacketCodec<? super RegistryByteBuf, T> codec);
    }
    
    public record BufCustomPacketPayload(Id<BufCustomPacketPayload> _type,
                                         byte[] payload) implements CustomPayload {
        @Override
        public Id<? extends CustomPayload> getId() {
            return this._type();
        }
        
        public static PacketCodec<ByteBuf, BufCustomPacketPayload> streamCodec(Id<BufCustomPacketPayload> type) {
            return PacketCodecs.BYTE_ARRAY.xmap(bytes -> new BufCustomPacketPayload(type, bytes), BufCustomPacketPayload::payload);
        }
    }
}
