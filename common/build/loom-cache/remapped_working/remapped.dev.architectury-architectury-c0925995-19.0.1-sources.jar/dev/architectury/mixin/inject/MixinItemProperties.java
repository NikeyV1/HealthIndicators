/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.mixin.inject;

import dev.architectury.extensions.injected.InjectedItemPropertiesExtension;
import dev.architectury.impl.ItemPropertiesExtensionImpl;
import dev.architectury.registry.CreativeTabRegistry;
import dev.architectury.registry.registries.DeferredSupplier;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraft.registry.RegistryKey;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(Item.Settings.class)
public class MixinItemProperties implements InjectedItemPropertiesExtension, ItemPropertiesExtensionImpl {
    @Unique
    private ItemGroup tab;
    @Unique
    private DeferredSupplier<ItemGroup> tabSupplier;
    
    @Override
    public Item.Settings arch$tab(ItemGroup tab) {
        this.tab = tab;
        this.tabSupplier = null;
        return (Item.Settings) (Object) this;
    }
    
    @Override
    public Item.Settings arch$tab(DeferredSupplier<ItemGroup> tab) {
        this.tab = null;
        this.tabSupplier = tab;
        return (Item.Settings) (Object) this;
    }
    
    @Override
    public Item.Settings arch$tab(RegistryKey<ItemGroup> tab) {
        this.tab = null;
        this.tabSupplier = CreativeTabRegistry.defer(tab);
        return (Item.Settings) (Object) this;
    }
    
    @Override
    @Nullable
    public ItemGroup arch$getTab() {
        return tab;
    }
    
    @Override
    @Nullable
    public DeferredSupplier<ItemGroup> arch$getTabSupplier() {
        return tabSupplier;
    }
}
